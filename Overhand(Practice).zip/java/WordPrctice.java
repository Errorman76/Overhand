package com.example.it.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by IT on 2017-07-22.
 */

public class WordPrctice extends Activity {

    int correctCount = 0;
    int wrongCount = 0;
    int accurate = 0;
    int ARR_NUM;
    int comp;

    TextView randomText, accurateText, wrongText;
    EditText editText;

    String word[] = {"약속", "시계", "겨울", "가을", "여름",
            "빵집", "찜닭", "현금", "피자", "영화",
            "새벽", "배달", "시간", "바다", "구름",
            "달력", "기차", "서울", "대구", "부산",
            "일본", "중국", "한국", "축구", "의자",
            "자리", "샤프", "지갑", "여권", "미국",
            "유럽", "교수", "학생", "버스", "커피",
            "야경", "공원", "뉴스", "온천", "날씨",
            "지진", "사과", "인터넷", "노트북", "수영장",
            "백화점", "휴대폰", "도서관", "햄버거", "파스타",
            "짜장면", "자동차", "비행기", "카메라", "지우개",
            "학생증", "신분증", "연예인", "드라마", "고양이",
            "초콜릿", "충전기", "지하철", "제주도", "바나나",
            "샌드위치", "된장찌개", "홈플러스", "스파게티", "바이올린",
            "고등학교", "아지랑이", "바퀴벌레", "사자성어", "마요네즈",
            "포장마차", "와이파이", "아르바이트", "아이스크림", "크리스마스",
            "화이트데이", "공기청정기", "오케스트라", "게스트하우스", "우즈베키스탄",
            "플레이스토어", "원자력발전소", "오스트레일리아", "사우디아라비아",
            "2012년", "1993년", "2004년","2015년","2016년", "2017년", "2018년",
            "2만5천원", "만9천8백원", "13만원",
            "12월", "11월", "10월","9월","8월","7월","6월","5월","4월","3월","2월","1월",
            "12시30분","6시","9시","8시","10시30분","4시30분"
    };
    Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word);

        ARR_NUM = word.length;
        random = new Random();
        randomText = (TextView) findViewById(R.id.randomText);
        editText = (EditText)findViewById(R.id.editText);
        editText.setInputType(0);  // 키패드 제거
        showWords();

        accurateText = (TextView)findViewById(R.id.accurateText);
        wrongText = (TextView) findViewById(R.id.wrongText);

        editText.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                // 입력되는 텍스트에 변화가 있을 때
                textCheck();
            }
            @Override
            public void afterTextChanged(Editable arg0) {} // 입력이 끝났을 때

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {} // 입력하기 전에
        });
    }

    private void textCheck() {

        String et = editText.getText().toString();
        String tv = randomText.getText().toString();
        boolean wordCheck = false;

        char[] arr_et = et.toCharArray();
        char[] arr_tv = tv.toCharArray();
        comp = tv.length();

        if (et.equals(tv)) {
            Toast.makeText(getApplicationContext(), "정답", Toast.LENGTH_SHORT).show(); // 임시임시임시
            correctCount++;
            showWords();
        }
        else if (et.length() == tv.length())
        {
            if (arr_et[comp - 1] == arr_tv[comp - 1]) {
                if (et.length() > tv.length()) {
                    wrongCount++;
                    showWords();
                    wrongText.setText("오타수 : " + wrongCount);  // test test test
                }
            }
        }
        else if(et.length() > tv.length())
        {
            if(arr_et[comp] == '·' || arr_et[comp] == '‥') {
                // '어', '고'와 같은 문자 입력시 도깨비불 현상(?)에 의한 오타 오류 처리
            }
            else {
                if (et.length() > (tv.length())) {
                    wrongCount++;
                    showWords();
                    wrongText.setText("오타수 : " + wrongCount);  // test test test
                }
            }
        }
        calcAccurate();
    }

    private void showWords()
    {
        randomText.setText(word[random.nextInt(ARR_NUM)]);
        editText.setText("");
    }

    private void calcAccurate()
    {
        if(correctCount != 0 || wrongCount != 0)
            accurate = (100 * correctCount / (correctCount + wrongCount));
        accurateText.setText("정확도 : " + accurate + "%");
    }
}
