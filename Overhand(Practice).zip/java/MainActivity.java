package com.example.it.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {

        Intent intent = new Intent(this, MainActivity.class);

        switch (view.getId()) {
            case R.id.level1:
                intent = new Intent(this, InitPractice.class);
                break;
            case R.id.level2:
                intent = new Intent(this, WordPrctice.class);
                break;
            case R.id.level3:
                intent = new Intent(this, ShortSentence.class);
                break;
            case R.id.level4:
                intent = new Intent(this, LongSentence.class);
                break;
            default:
                break;
        }
        startActivity(intent);
    }
}
