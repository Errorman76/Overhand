package com.example.it.myapplication;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by IT on 2017-07-22.
 */

public class ShortSentence extends Activity {

    int ARR_NUM;
    int correctCount = 0;
    int wrongCount = 0;
    int totalCount = 0;
    int setCorrect = 0;
    int setWrong = 0;
    //int backCount = 0;
    int accurate = 0;
    int comp;

    int rand;
    int time = 1;
    int typingSpeed = 0; // 현재 타수 = (입력한 타수 ? 백스페이스 * 3) / 경과시간 * 60

    String sentence[] = {
            "늦었다고 생각할 때가 정말 늦은 거다. 그러니 지금 당장 시작해라.",
            "지금 공부 안하면 더울 때 더운데서 일하고 추울 땐 추운데서 일한다.",
            "앞에서 할 수 없는 말은 뒤에서도 하지마라.",
            "적게 말하고 많이 들어라. 들을수록 내 편은 많아진다.",
            "내가 하고 싶은 말보다 상대방이 진정 듣고자 하는 말을 해라.",
            "무엇을 선택하느냐 보다 선택 이후의 행동이 더 중요하다.",
            "별로 의미가 없는 일이나 관심도 없는 일을 하기에 인생은 너무 짧다.",
            //"하늘의 별만을 바라보는 사람은 자기 발아래의 아름다운 꽃을 느끼지 못한다.",
            "쉽게 가질 수 있는 것은 쉽게 버려지는 경우가 많다.",
            "자신을 사랑하는 법을 아는 것이 가장 위대한 사람이다.",
            //"노력한다고 항상 성공할 수는 없지만 성공한 사람은 모두 노력했다는 걸 알아둬.",
            "자신이 할 수 있다고 생각하는 것보다 매일 조금씩 더 하라.",
            "만 명과의 관계는 쉬우나 한 명과의 관계는 어렵다.",
            "인생은 양파와 같다. 한 번에 한 꺼풀씩 벗기다 보면 눈물이 난다.",
            "무슨 일이든 조금씩 차근차근 해 나가면 그리 어렵지 않다.",
            //"때로는 기쁨이 미소의 근원이기도 하지만, 때로는 미소가 기쁨의 근원이 되기도 한다.",
            "하루하루를 어떻게 보내는가에 따라 우리의 인생이 결정된다.",
            "좋은 아이디어를 얻는 최선의 방법은 많이 생각하는 것이다.",
            "자선은 아무리 베풀어도 지나치지 않다.",
            "실수는 발견의 시작이다.",
            "행복은 마음먹기에 달려 있다.",
            "계획을 세우지 않은 목표는 한낱 꿈에 불과하다.",
            "잘못을 저지르는 것보다 변명하는 것이 더 나쁘다.",
            "노력만 하면 어떤 일에서든지 배울 점을 찾을 수 있다.",
            "주먹을 쥐고 있으면 악수할 수 없다.",
            "오래된 친구가 가장 좋은 거울이다.",
            //"진정으로 가난한 사람은 적게 가지고 있는 사람이 아니라 더 많은 것을 갈망하는 사람이다.",
            "야옹거리며 우는 고양이는 쥐를 잡을 수 없다.",
            "해변의 아름다운 조개껍데기를 모두 주울 수는 없다.",
            "기적을 바라되 의존하지는 말라.",
            "잘할 수 없다고 생각하며 아예 시도도 하지 않는 것만큼 큰 실수는 없다.",
            "열정을 상실한 사람은 노인과 같다.",
            "친구는 자기 자신에게 주는 선물이다.",
            "단점을 찾기는 쉽지만, 그것을 고치는 것은 어렵다.",
            "큰 성공은 작은 성공을 거듭한 결과이다.",
            "오늘의 위기는 내일의 농담거리다.",
            "변화가 필요하기 전에 변하라.",
            "지금의 나와 다른 내가 되고 싶다면, 지금의 나에 대해서 알아야 한다.",
            "지식은 다른 사람에게 전달할 수 있지만 지혜는 그렇지 않다.",
            ""
    };

    Random random = new Random();
    private TextView randomText, accurateText, wrongText;
    private EditText editText;

    Handler mHandler = new Handler(){
        public void handleMessage(Message msg){
            TextView typingText = (TextView) findViewById(R.id.typingText);
            time++;
            typingSpeed = (60 * correctCount / time);  // 현재 타수 = (입력한 타수 ? 백스페이스 * 3) / 경과시간 * 60
            typingText.setText("현재 타수 : " + Integer.toString(typingSpeed));
            mHandler.sendEmptyMessageDelayed(0,500); // 0.5초 지연
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_short);

        mHandler.sendEmptyMessage(0);

        ARR_NUM = sentence.length;
        randomText = (TextView) findViewById(R.id.randomText);
        editText = (EditText)findViewById(R.id.editText);
        editText.setInputType(0);  // 키패드 제거

        randomText.setText(sentence[random.nextInt(ARR_NUM)]);
        accurateText = (TextView)findViewById(R.id.accurateText);
        wrongText = (TextView) findViewById(R.id.wrongText);

        editText.addTextChangedListener(new TextWatcher() {
            String et, tv;

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // 입력되는 텍스트에 변화가 있을 때
                textcheck();
            }

            @Override
            public void afterTextChanged(Editable arg0) {} // 입력이 끝났을 때

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {} // 입력하기 전에
        });

        editText.setOnKeyListener(new View.OnKeyListener()
        {
            public boolean onKey(View view, int keyCode, KeyEvent event)
            {
                if(keyCode ==  KeyEvent.KEYCODE_ENTER && KeyEvent.ACTION_DOWN == event.getAction())
                {
                    // 엔터키 눌렀을 때
                    TextView tv = (TextView) findViewById(R.id.randomText);

                    if(editText.length() == tv.length())
                    {
                        // 문장이 틀려도 길이가 같거나 길면 다음 문장으로
                        showSentence();
                    }
                    return true;
                }
                // TODO Auto-generated method stub
                return false;
            }
        });
    }

    private void textcheck()
    {
        String et = editText.getText().toString();
        String tv = randomText.getText().toString();
        boolean lineCheck = false;
        SpannableStringBuilder ssb = new SpannableStringBuilder(tv);

        if(et.length() != 0)
        {
            char[] arr_et = et.toCharArray();
            char[] arr_tv = tv.toCharArray();

            correctCount = setCorrect;
            wrongCount = setWrong; // 초기화

            comp = et.length();
            if(et.length() > tv.length()) comp = tv.length();

            for (int i = 0; i < comp; i++) {
                if (arr_et[i] == arr_tv[i]) {
                    ssb.setSpan(new ForegroundColorSpan(Color.parseColor("#0000FF")), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    correctCount++;
                    if (i == tv.length() - 1)
                        lineCheck = true; // 마지막 글자가 올바른지 체크
                }  else {
                    ssb.setSpan(new ForegroundColorSpan(Color.parseColor("#FF0000")), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    ssb.setSpan(new ForegroundColorSpan(Color.parseColor("#00FF00")), comp - 1, comp, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    wrongCount++;
                }

            }
        }
        calcAccurate();
        randomText.setText(ssb);

        if(lineCheck == false) {
            // '어', '고'와 같은 문자 입력시 도깨비불 현상(?)에 의한 오타 오류 처리
            // 올바른 입력이면 다음 문장으로
            if (et.equals(tv) || et.length() > tv.length() + 1)
                showSentence();
        }
        else {
            // 올바른 입력이면 다음 문장으로
            if (et.equals(tv) || et.length() > tv.length())
                showSentence();
        }
    }

    private void showSentence()
    {
        randomText.setText(sentence[random.nextInt(ARR_NUM)]);
        editText.setText("");
        setCorrect = correctCount;
        setWrong = wrongCount;
    }

    private void calcAccurate()
    {
        totalCount = correctCount + wrongCount;
        accurate = (100 * correctCount / totalCount);
        accurateText.setText("정확도 : " + Integer.toString(accurate) + " %");
        wrongText.setText("오타수 : " +  Integer.toString(wrongCount));
    }
}
