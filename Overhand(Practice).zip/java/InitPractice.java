package com.example.it.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by IT on 2017-07-22.
 */

public class InitPractice extends Activity {

    int rand;
    final static int ARR_NUM = 43;
    TextView randomText;
    EditText editText;
    Random random;
    String value[] = {"ㄱ","ㅋ","ㄲ","ㅇ","ㅎ",
            "ㅈ","ㅊ","ㅉ","ㅁ","ㅍ",
            "ㅅ","ㅆ","ㄴ","ㄹ","ㄷ",
            "ㅌ","ㄸ","ㅂ","ㅃ","ㅣ",
            "ㅡ","ㅏ","ㅑ","ㅓ","ㅕ",
            "ㅗ","ㅛ","ㅜ","ㅠ","ㅔ",
            "ㅐ","ㅖ","ㅒ","0","1",
            "2","3","4","5","6",
            "7","8","9"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_init);

        random = new Random();
        randomText = (TextView) findViewById(R.id.randomText);
        editText = (EditText)findViewById(R.id.editText);
        editText.setInputType(0);  // 키패드 제거

        rand = random.nextInt(ARR_NUM);
        randomText.setText(value[rand]);
        showGesture(value[rand]);

        editText.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}                // 입력되는 텍스트에 변화가 있을 때

            @Override
            public void afterTextChanged(Editable arg0) {
                // 입력이 끝났을 때
               textCheck();
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                // 입력하기 전에
        });
    }

    private void mark (final ImageView target, int time) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Animation focus = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim);
                target.startAnimation(focus);
            }
        }, time);
    }
    private void textCheck()
    {
        String input = editText.getText().toString();

        if (input.equals(randomText.getText().toString())) {
            Toast.makeText(getApplicationContext(), "정답", Toast.LENGTH_SHORT).show(); // 임시임시임시
            rand = random.nextInt(ARR_NUM);
            randomText.setText(value[rand]);
            showGesture(value[rand]);
            editText.setText("");
        }
    }

    private void showGesture(String c)
    {
        ImageView thumb = (ImageView)findViewById(R.id.thumb);
        ImageView index = (ImageView)findViewById(R.id.index);
        ImageView middle = (ImageView)findViewById(R.id.middle);
        ImageView ring = (ImageView)findViewById(R.id.ring);
        ImageView little = (ImageView)findViewById(R.id.little);

        // 기존 애니메이션 효과 중지
        thumb.clearAnimation();
        index.clearAnimation();
        middle.clearAnimation();
        ring.clearAnimation();
        little.clearAnimation();

        switch(c)
        {
            case "0":
                mark(thumb,500);
                break;
            case "1":
                mark(index, 500);
                break;
            case "2":
                mark(middle, 500);
                break;
            case "3":
                mark(ring, 500);
                break;
            case "4":
                mark(little, 500);
                break;
            case "5":
                mark(thumb, 500);
                mark(index, 500);
                break;
            case "6":
                mark(thumb, 500);
                mark(middle, 500);
                break;
            case "7":
                mark(thumb, 500);
                mark(ring, 500);
                break;
            case "8":
                mark(thumb, 500);
                mark(little, 500);
                break;
            case "9":
                mark(index, 500);
                mark(middle, 500);
                mark(ring, 500);
                mark(little, 500);
                break;
            case "ㄱ": // ㄱ
                mark(index, 500);
                break;
            case "ㅋ": // ㅋ
                mark(thumb, 500);
                mark(index, 1000);
                break;
            case "ㄲ": // ㄲ
                mark(index, 500);
                mark(thumb, 1000);
                break;
            case "ㅇ": // ㅇ
                mark(middle, 500);
                break;
            case "ㅎ": // ㅎ
                mark(thumb, 500);
                mark(middle, 1000);
                break;
            case "ㅈ": // ㅈ
                mark(ring, 500);
                break;
            case "ㅊ": // ㅊ
                mark(thumb, 500);
                mark(ring, 1000);
                break;
            case "ㅉ": // ㅉ
                mark(ring, 500);
                mark(thumb, 1000);
                break;
            case "ㅁ": // ㅁ
                mark(little, 500);
                break;
            case "ㅍ": // ㅍ
                mark(thumb, 500);
                mark(little, 1000);
                break;
            case "ㅅ": // ㅅ
                mark(index, 500);
                mark(middle, 500);
                break;
            case "ㅆ": // ㅆ
                mark(index, 500);
                mark(middle, 500);
                mark(thumb, 1000);
                break;
            case "ㄴ": // ㄴ
                mark(index, 500);
                mark(little, 500);
                break;
            case "ㄹ": // ㄹ
                mark(thumb, 500);
                mark(index, 1000);
                mark(little, 1000);
                break;
            case "ㄷ": // ㄷ
                mark(index, 500);
                mark(ring, 500);
                break;
            case "ㅌ": // ㅌ
                mark(thumb, 500);
                mark(index, 1000);
                mark(ring, 1000);
                break;
            case "ㄸ": // ㄸ
                mark(index, 500);
                mark(ring, 500);
                mark(thumb, 1000);
                break;
            case "ㅂ": // ㅂ
                mark(index, 500);
                mark(middle, 500);
                mark(ring, 500);
                mark(little, 500);
                break;
            case "ㅃ": // ㅃ
                mark(index, 500);
                mark(middle, 500);
                mark(ring, 500);
                mark(little, 500);
                mark(thumb, 1000);
                break;
            case "ㅣ": // ㅣ
                mark(index, 500);
                break;
            case "ㅡ": // ㅡ
                mark(middle, 500);
                break;
            case "ㅏ": // ㅏ
                mark(ring, 500);
                break;
            case "ㅑ": // ㅑ
                mark(ring, 500);
                mark(thumb, 1000);
                break;
            case "ㅓ": // ㅓ
                mark(little, 500);
                break;
            case "ㅕ": // ㅕ
                mark(little, 500);
                mark(thumb, 1000);
                break;
            case "ㅗ": // ㅗ
                mark(thumb, 500);
                mark(middle, 1000);
                break;
            case "ㅛ": // ㅛ
                mark(thumb, 500);
                mark(thumb, 1000);
                mark(middle, 1500);
                break;
            case "ㅜ": // ㅜ
                mark(middle, 500);
                mark(thumb, 1000);
                break;
            case "ㅠ": // ㅠ
                mark(middle, 500);
                mark(thumb, 1000);
                mark(thumb, 1500);
                break;
            case "ㅔ": // ㅔ
                mark(little, 500);
                mark(index, 1000);
                break;
            case "ㅐ": // ㅐ
                mark(ring, 500);
                mark(index, 1000);
                break;
            case "ㅖ": // ㅖ
                mark(little, 500);
                mark(thumb, 1000);
                mark(index, 1500);
                break;
            case "ㅒ": // ㅒ
                mark(ring, 500);
                mark(thumb, 1000);
                mark(index, 1500);
                break;
        }
    }
}
