package com.example.it.myapplication;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.TabStopSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by IT on 2017-07-22.
 */

public class LongSentence extends Activity {

    int x = 0, y = 0;
    int correctCount = 0;
    int setCorrect = 0;
    int wrongCount = 0;
    int setWrong = 0;
    int comp;
    int totalCount = 0;
    int accurate = 0;

    int time = 1;
    int typingSpeed = 0; // 현재 타수 = (입력한 타수 ? 백스페이스 * 3) / 경과시간 * 60
    View finish;

    String sentence[][] = {
            {
                    "별 헤는 밤",
                    "계절이 지나가는 하늘에는",
                    "가을로 가득 차 있습니다.",

                    "나는 아무 걱정도 없이",
                    "가을 속의 별들을 다 헬 듯합니다.",

                    "가슴 속에 하나 둘 새겨지는 별을",
                    "이제 다 못 헤는 것은",
                    "쉬이 아침이 오는 까닭이요,",
                    "내일 밤이 남은 까닭이요,",
                    "아직 나의 청춘이 다하지 않은 까닭입니다.",

                    "별 하나에 추억과",
                    "별 하나에 사랑과",
                    "별 하나에 쓸쓸함과",
                    "별 하나에 동경과",
                    "별 하나에 시와",
                    "별 하나에 어머니, 어머니,",

                    "어머님, 나는 별 하나에 아름다운 말 한마디씩 불러 봅니다.",
                    "소학교 때 책상을 같이 했던 아이들의 이름과,",
                    "패, 경, 옥, 이런 이국 소녀들의 이름과,",
                    "벌써 아기 어머니 된 계집애들의 이름과,",
                    "가난한 이웃 사람들의 이름과,",
                    "비둘기, 강아지, 토끼, 노새, 노루, 프랑시스 잠, 라이너 마리아 릴케",
                    "이런 시인의 이름을 불러 봅니다.",

                    "이네들은 너무나 멀리 있습니다.",
                    "별이 아스라이 멀듯이.",

                    "어머님, 그리고 당신은 멀리 북간도에 계십니다.",

                    "나는 무엇인지 그리워",
                    "이 많은 별빛이 내린 언덕 위에",
                    "내 이름자를 써 보고",
                    "흙으로 덮어 버리었습니다.",

                    "딴은 밤을 새워 우는 벌레는",
                    "부끄러운 이름을 슬퍼하는 까닭입니다.",

                    "그러나 겨울이 지나고 나의 별에도 봄이 오면",
                    "무덤 위에 파란 잔디가 피어나듯이",
                    "내 이름자 묻힌 언덕 위에도",
                    "자랑처럼 풀이 무성할 거외다."
            },
            {
                    "세계인의 축제, 제23회 동계올림픽대회는",
                    "대한민국 강원도 평창에서 2018년 2월 9일부터 25일까지 17일간 개최됩니다.",
                    "대한민국 평창은 세 번의 도전 끝에 지난 2011년 7월 6일 열린 제 123차 국제올림픽위원회 총회에서",
                    "과반 표를 획득하며 2018년 동계올림픽 개최지로 선정되었습니다.",
                    "이로써 대한민국에서는 1988년 서울 올림픽 이후 30년 만에, ",
                    "평창에서 개,폐회식과 대부분의 설상 경기가 개최되며, ",
                    "강릉에서는 빙상 종목 전 경기가, ",
                    "그리고 정선에서는 알파인 스키 활강 경기가 개최될 예정입니다."
            }
    };
    Random random = new Random();
//"몇 글자가 한줄에 나오는게 가장 적합할지 확인하기 위해 넣은 문장입니다. 글자 수를 판단하여 화면이 들어오는 가장 최적의 최대 길이를 찾기 위한 문장입니다."

    private TextView tv1, tv2, tv3, tv4, tv5;
    private EditText et1, et2, et3, et4, et5;

    private TextView accurateText;
    private TextView wrongText;

    Handler mHandler = new Handler(){
        public void handleMessage(Message msg){
            TextView typingText = (TextView) findViewById(R.id.typingText);
            time++;
            typingSpeed = (60 * correctCount / time);  // 현재 타수 = (입력한 타수 ? 백스페이스 * 3) / 경과시간 * 60
            typingText.setText("현재 타수 : " + Integer.toString(typingSpeed));
            mHandler.sendEmptyMessageDelayed(0,500); // 0.5초 지연
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_long);

        mHandler.sendEmptyMessage(0);

        tv1 = (TextView)findViewById(R.id.tv1);
        tv2 = (TextView)findViewById(R.id.tv2);
        tv3 = (TextView)findViewById(R.id.tv3);
        tv4 = (TextView)findViewById(R.id.tv4);
        tv5 = (TextView)findViewById(R.id.tv5);

        et1 = (EditText)findViewById(R.id.et1);
        et2 = (EditText)findViewById(R.id.et2);
        et3 = (EditText)findViewById(R.id.et3);
        et4 = (EditText)findViewById(R.id.et4);
        et5 = (EditText)findViewById(R.id.et5);

        et1.setInputType(0);  // 키패드 제거
        et2.setInputType(0);  // 키패드 제거
        et3.setInputType(0);  // 키패드 제거
        et4.setInputType(0);  // 키패드 제거
        et5.setInputType(0);  // 키패드 제거


        finish = tv1; // 더미값

        // EditText 터치 금지
        et2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
        et3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
        et4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
        et5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

        accurateText = (TextView)findViewById(R.id.accurateText);
        wrongText = (TextView)findViewById(R.id.wrongText);

        x = random.nextInt(sentence.length);
        tv1.setText(sentence[x][y]);
        tv2.setText(sentence[x][y+1]);
        tv3.setText(sentence[x][y+2]);
        tv4.setText(sentence[x][y+3]);
        tv5.setText(sentence[x][y+4]);

        editTextListener(et1, tv1);
        editTextListener(et2, tv2);
        editTextListener(et3, tv3);
        editTextListener(et4, tv4);
        editTextListener(et5, tv5);
    }

    private void editTextListener(final TextView edt, final TextView txv) {

        edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // 입력되는 텍스트에 변화가 있을 때
                textcheck(edt, txv);
            }

            @Override
            public void afterTextChanged(Editable arg0) {} // 입력이 끝났을 때

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {} // 입력하기 전에
        });
    }

    private void textcheck(TextView edt, TextView txv)
    {
        String et = edt.getText().toString();
        String tv = txv.getText().toString();
        boolean lineCheck = false;
        SpannableStringBuilder ssb = new SpannableStringBuilder(tv);

        if (et.length() != 0) {
            char[] arr_et = et.toCharArray();
            char[] arr_tv = tv.toCharArray();

            correctCount = setCorrect;
            wrongCount = setWrong; // 초기화

            comp = et.length();
            if (et.length() > tv.length()) comp = tv.length();

            for (int i = 0; i < comp; i++) {
                if (arr_et[i] == arr_tv[i]) {
                    ssb.setSpan(new ForegroundColorSpan(Color.parseColor("#0000FF")), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    correctCount++;
                    if(i == tv.length() -1)
                        lineCheck = true; // 마지막 글자가 올바른지 체크
                } else {
                    ssb.setSpan(new ForegroundColorSpan(Color.parseColor("#FF0000")), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    ssb.setSpan(new ForegroundColorSpan(Color.parseColor("#00FF00")), comp - 1, comp, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    wrongCount++;
                }
            }
        }
        calcAccurate();
        txv.setText(ssb);

        if(lineCheck == false)
        {
            // '어', '고'와 같은 문자 입력시 도깨비불 현상(?)에 의한 오타 오류 처리
            if (et.equals(tv) || et.length() > tv.length() + 1)
                showSentence(edt);
        }
        else
        {
            // 올바른 입력이면 다음 문장으로
            if (et.equals(tv) || et.length() > tv.length())
                showSentence(edt);
        }
    }

    private void showSentence(TextView edt)
    {
        setCorrect = correctCount;
        setWrong = wrongCount;
        // et5는 다른 처리
        if (edt.equals(et5)) {
            et1.requestFocus();
            y += 5;

            if (y + 4 < sentence[x].length)
                tv5.setText(sentence[x][y + 4]);
            else {
                tv5.setVisibility(View.INVISIBLE);
                et5.setVisibility(View.INVISIBLE);
                finish = et4;
            }

            if (y + 3 < sentence[x].length)
                tv4.setText(sentence[x][y + 3]);
            else {
                tv4.setVisibility(View.INVISIBLE);
                et4.setVisibility(View.INVISIBLE);
                finish = et3;
            }

            if (y + 2 < sentence[x].length)
                tv3.setText(sentence[x][y + 2]);
            else {
                tv3.setVisibility(View.INVISIBLE);
                et3.setVisibility(View.INVISIBLE);
                finish = et2;
            }

            if (y + 1 < sentence[x].length)
                tv2.setText(sentence[x][y + 1]);
            else {
                tv2.setVisibility(View.INVISIBLE);
                et2.setVisibility(View.INVISIBLE);
                finish = et1;
            }

            if (y < sentence[x].length)
                tv1.setText(sentence[x][y]);
            else {
                tv1.setVisibility(View.INVISIBLE);
                et1.setVisibility(View.INVISIBLE);
                finish = et5;
            }

            et1.setText("");
            et2.setText("");
            et3.setText("");
            et4.setText("");
            et5.setText("");
        }
        // ed5가 아닌 나머지
        else {
            View cursor = getCurrentFocus();
            if (cursor.equals(et1)) et2.requestFocus();
            if (cursor.equals(et2)) et3.requestFocus();
            if (cursor.equals(et3)) et4.requestFocus();
            if (cursor.equals(et4)) et5.requestFocus();
        }
        typingInfo(edt);
    }

    private void calcAccurate()
    {
        totalCount = correctCount + wrongCount;
        accurate = (100 * correctCount / totalCount);
        accurateText.setText("정확도 : " + Integer.toString(accurate) + " %");
        wrongText.setText("오타수 : " + Integer.toString(wrongCount));
    }

    private void typingInfo(TextView edt)
    {
        if (finish.equals(edt)) {
            AlertDialog.Builder confirm = new AlertDialog.Builder(LongSentence.this);
            confirm.setCancelable(false);
            confirm.setTitle("알림")
                    .setMessage("현재 타수 : " + typingSpeed + "\n정확도 : " + accurate)
                    .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(LongSentence.this, MainActivity.class);
                            startActivity(intent);
                        }
                    }).create().show();
        }
    }
}
