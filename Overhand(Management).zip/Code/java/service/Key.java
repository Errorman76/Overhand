package com.klasis.overhand.service;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.inputmethodservice.InputMethodService;
import android.os.*;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import com.klasis.overhand.R;
import com.klasis.overhand.utils.Constants;

import java.util.List;

/**
 * 키 입력 처리 클래스
 * Created by Klasis on 2017-08-22.
 */

public class Key extends InputMethodService {

    // Debugging
    private final static String TAG = "Key";

    // Communication
    private com.klasis.overhand.service.Message msgService = null;
    public KeyHandler keyHandler = null;
    public Handler msgHandler = null;

    // 조립 문자열
    private StringBuilder mComp = new StringBuilder();

    // 한글 모드
    private boolean koreanMode = false;

    // 입력중인 초성, 중성, 종성 개별 음소들. 99면 없다는 뜻이다.
    // 조합형은 비트 연산해서 추출할 수 있지만 유니코드는 어려우므로 별도의 변수에 기록한다.
    // 꼭 추출하려면 가능은 하지만 속도상의 문제도 있고 해서 음소별로 저장했다.
    // 복자음, 복모음도 하나의 변수에 기록해 두고 필요시 분리해서 조사한다.
    private int cho, jung, jong;

    // 한글 조립 상태에 대한 상수
    private final int H_NONE = 0;			// 아무것도 없는 상태				예:
    private final int H_CHO = 1;			// 초성 하나 입력된 상태. 			예:ㄱ, ㄳ
    private final int H_JUNGONLY = 2;		// 초성없이 중성만 입력된 상태. 	예:ㅏ
    private final int H_JUNG = 3;			// 초성 + 중성. 					예:가, 과
    private final int H_JONG = 4;			// 초성 + 중성 + 종성				예:각, 닭

    // 각 음소별 속성
    // 첨자 0 : 0이면 자음, 1이면 모음
    // 첨자 1 : 초성의 순서값. 99는 낱글자 구성만 가능하고 음절은 불가하다는 뜻
    //        : 중성은 음소의 등장 순서가 코드 순서와 일치하므로 -30하면 됨
    // 첨자 2 : 종성의 순서값. 종성이 없을 경우는 0임. 99는 종성으로 쓸 수 없는 문자
    private int[][] hanattr = {
            {0, 0, 1},		// 0.ㄱ
            {0, 1, 2},		// 1.ㄲ
            {0,99, 3},		// 2.ㄳ
            {0, 2, 4},		// 3.ㄴ
            {0,99, 5},		// 4.ㄵ
            {0,99, 6},		// 5.ㄶ
            {0, 3, 7},		// 6.ㄷ
            {0, 4,99},		// 7.ㄸ
            {0, 5, 8},		// 8.ㄹ
            {0,99, 9},		// 9.ㄺ
            {0,99,10},		// 10.ㄻ
            {0,99,11},		// 11.ㄼ
            {0,99,12},		// 12.ㄽ
            {0,99,13},		// 13.ㄾ
            {0,99,14},		// 14.ㄿ
            {0,99,15},		// 15.ㅀ
            {0, 6,16},		// 16.ㅁ
            {0, 7,17},		// 17.ㅂ
            {0, 8,99},		// 18.ㅃ
            {0,99,18},		// 19.ㅄ
            {0, 9,19},		// 20.ㅅ
            {0,10,20},		// 21.ㅆ
            {0,11,21},		// 22.ㅇ
            {0,12,22},		// 23.ㅈ
            {0,13,99},		// 24.ㅉ
            {0,14,23},		// 25.ㅊ
            {0,15,24},		// 26.ㅋ
            {0,16,25},		// 27.ㅌ
            {0,17,26},		// 28.ㅍ
            {0,18,27},		// 29.ㅎ
            {1, 0, 0},		// 30.ㅏ
            {1, 0, 0},		// 31.ㅐ
            {1, 0, 0},		// 32.ㅑ
            {1, 0, 0},		// 33.ㅒ
            {1, 0, 0},		// 34.ㅓ
            {1, 0, 0},		// 35.ㅔ
            {1, 0, 0},		// 36.ㅕ
            {1, 0, 0},		// 37.ㅖ
            {1, 0, 0},		// 38.ㅗ
            {1, 0, 0},		// 39.ㅘ
            {1, 0, 0},		// 40.ㅙ
            {1, 0, 0},		// 41.ㅚ
            {1, 0, 0},		// 42.ㅛ
            {1, 0, 0},		// 43.ㅜ
            {1, 0, 0},		// 44.ㅝ
            {1, 0, 0},		// 45.ㅞ
            {1, 0, 0},		// 46.ㅟ
            {1, 0, 0},		// 47.ㅠ
            {1, 0, 0},		// 48.ㅡ
            {1, 0, 0},		// 49.ㅢ
            {1, 0, 0},		// 50.ㅣ
    };

    /**
     * 최초 실행 시 초기화
     */
    @Override
    public void onInitializeInterface() {
        super.onInitializeInterface();
        Log.d(TAG, "onInitializeInterface() : start");

        // KeyHandler 초기화
        keyHandler = new KeyHandler();

        // Message 서비스 시작
        startMsgService();
    }

    /**
     * 키 입력 시작 시 초기화
     */
    @Override
    public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
        Log.d(TAG, "onStartInput() : start");

        // KeyHandler 초기화
        if (keyHandler == null)
            keyHandler = new KeyHandler();

        // Message 서비스 확인
        if (!checkMsgService()) {
            // Message 서비스가 실행되지 않은 경우
            Log.d(TAG, "onStartInput() : Message service is NOT running");

            // Message 서비스 시작
            startMsgService();
        }

        // 한글/숫자 모드 초기화
        koreanMode = false;

        // 한글 입력기 초기화
        ResetCompo();
    }

    /**
     * 키 입력 종료 시 이벤트
     */
    @Override
    public void onFinishInput() {
        super.onFinishInput();
        Log.d(TAG, "onFinishInput() : start");
    }

    /**
     * 키 입력 중 선택 영역 또는 커서 위치 변경 시 이벤트
     */
    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        // 선택 영역 또는 커서 위치 변경 시 한글 조립 완성
        if(mComp.length() > 0 && (oldSelStart != candidatesStart || newSelEnd != candidatesEnd)) {
            // 임시적으로 조립이 풀린 경우를 제외
            if (candidatesStart != -1) {
                ResetCompo();
                FinishCompo();
            }
        }
    }

    /**
     * Message Service로부터 받은 입력 코드를 분석
     * @param code      입력 코드
     */
    public void keyService(int code) {
        int type;

        if (code >= 0 && code <= 9)
            type = Constants.KEYCODE_NUM;
        else if (code >= 10 && code <= 42)
            type = Constants.KEYCODE_CHAR;
        else if (code == 43)
            type = Constants.KEYCODE_ENTER;
        else if (code == 44)
            type = Constants.KEYCODE_SPACE;
        else if (code == 45)
            type = Constants.KEYCODE_DELETE;
        else {
            // 등록되지 않은 키 코드일 경우
            return;
        }

        // 유니코드 문자로 변환 및 키 입력 처리
        outputKey(type, converseKey(code));
    }

    /**
     * 입력 코드를 입력 키(유니코드)로 변환
     * @param code      입력 코드
     * @return int      입력 키
     */
    public int converseKey(int code) {
        int keycode[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ',
                            'ㅇ', 'ㅈ','ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ', 'ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ',
                            'ㅗ', 'ㅛ', 'ㅜ', 'ㅠ', 'ㅡ', 'ㅣ', KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_DEL};

        return keycode[code];
    }

    /**
     * 입력 키를 출력 (필요 시 한글 오토마타 이용)
     * @param type      입력 키의 유형
     * @param key       입력 키
     */
    public void outputKey(int type, int key) {
        switch (type) {
            // Delete 키
            case Constants.KEYCODE_DELETE:
                // '지움' 키 입력
                if (koreanMode) {
                    // 현재 모드 : 한글
                    revKoreanAutomata();
                }
                else {
                    // 현재 모드 : 숫자
                    keyDownUp(key);
                }
                break;

            // 숫자 키
            case Constants.KEYCODE_NUM:
                // 조립 문자열 완성
                if (mComp.length() > 0) {
                    FinishCompo();
                    ResetCompo();
                }
                // 숫자 키 입력
                getCurrentInputConnection().commitText(String.valueOf((char) key), 1);

                // 변경 모드 : 한글 -> 숫자
                koreanMode = false;
                break;

            // Enter, Space Bar 키
            case Constants.KEYCODE_ENTER:
            case Constants.KEYCODE_SPACE:
                // 조립 문자열 완성
                if (mComp.length() > 0) {
                    FinishCompo();
                    ResetCompo();
                }
                // Enter, Space Bar 키 입력
                keyDownUp(key);

                // 변경 모드 : 한글 -> 숫자
                koreanMode = false;
                break;

            // 문자 키
            case Constants.KEYCODE_CHAR:
                // 문자 키 입력
                koreanAutomata(key);

                // 변경 모드 : 한글 -> 숫자
                koreanMode = true;
                break;

            default:
                break;
        }
    }

    // 키를 눌렀다가 떼는 동작을 하는 도우미 함수
    private void keyDownUp(int keyEventCode) {
        getCurrentInputConnection().sendKeyEvent(
                new KeyEvent(KeyEvent.ACTION_DOWN, keyEventCode));
        getCurrentInputConnection().sendKeyEvent(
                new KeyEvent(KeyEvent.ACTION_UP, keyEventCode));
    }

    /**
     * 한글 입력 처리
     * @param code      문자 키
     */
    private void koreanAutomata(int code) {
        boolean bConso;
        int idx;

        InputConnection ime = getCurrentInputConnection();
        if(ime == null) {
            Log.d(TAG, "InputConnection is null.");
            return;
        }

        // XML 문서의 키 코드를 ㄱ을 베이스로 한 첨자로 변환한다.
        // 이 첨자는 유니코드상 낱글자의 순서값이며 음소의 코드로 사용한다.
        if (code >= 0x3131 && code <= 0x3163) {
            idx = code - 0x3131;
        } else {
            // 한글이 아닌 다른 문자이면 조립을 끝낸다.
            FinishCompo();
            ResetCompo();

            // 문자 입력
            getCurrentInputConnection().commitText(String.valueOf((char)code), 1);
            return;
        }

        Log.d(TAG, "State = " + GetHanState() + ",idx = " + idx);

        // 입력된 글자가 자음인지 조사한다.
        if (hanattr[idx][0] == 0) {
            bConso = true;
        } else {
            bConso = false;
        }

        // 조립 상태에 따라 분기한다. 이후 입력된 글자의 자음, 모음 여부와 기존 글자의
        // 복자음, 복모음 여부에 따라 다양하게 분기된다.
        switch(GetHanState()) {
            case H_NONE:
                // 자음이면 자음 단독으로 입력한다. 낱글자 코드를 쓰면 된다.
                if (bConso) {
                    cho = idx;
                    AppendCompo(idx + 0x3131);
                    // 모음이면 모음만으로 글자 구성.
                } else {
                    jung = idx;
                    AppendCompo(idx + 0x3131);
                }
                break;
            case H_CHO:
                if (!IsBokJa(cho)) {
                    if (bConso) {
                        int bokja = findBokJa(cho, idx);
                        // 복자음 구성 가능하면 복자음만으로 초성 만듬. 예:ㄱ상태에서 ㅅ입력시 ㄳ
                        if (bokja != 99) {
                            cho = bokja;
                            ReplaceCompo(cho + 0x3131);
                            // 복자음 구성되지 않을 경우 - 음절 분리. 예:ㄱ 상태에서 ㄴ입력시
                        } else {
                            // 조립중인 글자 완성하고 새로 입력된 초성으로 단독 글자 만듬
                            FinishCompo();
                            ResetCompo();
                            cho = idx;
                            AppendCompo(cho + 0x3131);
                        }
                    } else {
                        // 모음이면 앞에 입력된 자음과 결합하여 새 글자로 대체. 예:ㄱ 상태에서 ㅏ입력시 가
                        jung = idx;
                        ReplaceCompo(GetHanCode(cho, jung, 99));
                    }
                } else {
                    // 복자음 초성만 입력된 상태에서 또 자음이 들어올 경우. 예:ㄳ 상태에서 ㄴ입력시 ㄳㄴ
                    if (bConso) {
                        // 새로 입력된 초성으로 단독 글자 만듬
                        FinishCompo();
                        ResetCompo();
                        cho = idx;
                        AppendCompo(cho + 0x3131);
                    } else {
                        // 복자음 앞쪽 초성만으로 한 글자 완성. 예:ㄳ상태에서 ㅏ 입력시 ㄱ사
                        ReplaceCompo(GetLeftBokJa(cho) + 0x3131);

                        // 복자음 뒤쪽 글자와 새로 입력된 중성과 조합하여 새 음절 분리
                        FinishCompo();
                        int newcho = GetRightBokJa(cho);
                        ResetCompo();
                        cho = newcho;
                        jung = idx;
                        AppendCompo(GetHanCode(cho, jung, 99));
                    }
                }
                break;
            case H_JUNGONLY:
                // 모음만 입력된 상태에서 자음이 들어오면 음절 분리. 예:ㅏ상태에서 ㄱ입력시 ㅏㄱ
                if (bConso) {
                    // 새로 입력된 초성으로 단독 글자 만듬
                    FinishCompo();
                    ResetCompo();
                    cho = idx;
                    AppendCompo(cho + 0x3131);
                } else {
                    int bokmo = findBokMo(jung, idx);
                    // 복모음 구성 가능하면 복모음으로 대체. 단 초성은 없음. 예:ㅗ상태에서 ㅏ입력시 ㅘ
                    if (bokmo != 99) {
                        jung = bokmo;
                        ReplaceCompo(jung + 0x3131);
                        // 복모음 구성되지 않을 경우 - 음절 분리
                    } else {
                        // 새로 입력된 중성으로 단독 글자 만듬
                        FinishCompo();
                        ResetCompo();
                        jung = idx;
                        AppendCompo(jung + 0x3131);
                    }
                }
                break;
            case H_JUNG:
                // 자음이면 받침으로
                if (bConso) {
                    // 받침이 될 수 없는 글자인 경우 음절 분리. 예:아 상태에서 ㄸ입력시 아ㄸ
                    if (hanattr[idx][2] == 99) {
                        // 조립중인 글자 완성
                        FinishCompo();

                        // 새로 입력된 초성으로 단독 글자 만듬
                        ResetCompo();
                        cho = idx;
                        AppendCompo(cho + 0x3131);
                    } else {
                        jong = idx;
                        ReplaceCompo(GetHanCode(cho, jung, jong));
                    }
                    // 또 모음이면 복모음 구성
                } else {
                    int bokmo = findBokMo(jung, idx);
                    // 복모음 구성 가능하면 복모음으로 대체
                    if (bokmo != 99) {
                        jung = bokmo;
                        ReplaceCompo(GetHanCode(cho, jung, jong));
                        // 복모음 구성되지 않을 경우 - 음절 분리. 예:아 상태에서 ㅓ입력시 아ㅓ
                    } else {
                        // 조립중인 글자 완성
                        FinishCompo();

                        // 중성만으로 글자 구성
                        ResetCompo();
                        jung = idx;
                        AppendCompo(jung + 0x3131);
                    }
                }
                break;
            case H_JONG:
                if (!IsBokJa(jong)) {
                    // 자음이면 복자음 받침 구성. 또는 새 음절로 분리
                    if (bConso) {
                        int bokja = findBokJa(jong, idx);
                        // 복자음 구성 가능하면 복자음 받침으로 대체. 예:달 상태에서 ㄱ입력시 닭
                        if (bokja != 99) {
                            jong = bokja;
                            ReplaceCompo(GetHanCode(cho, jung, jong));
                            // 복자음 구성되지 않을 경우 - 음절 분리
                        } else {
                            // 조립중인 글자 완성
                            FinishCompo();

                            // 새로 입력된 초성으로 단독 글자 만듬
                            ResetCompo();
                            cho = idx;
                            AppendCompo(cho + 0x3131);
                        }
                        // 모음이면 음절 분리
                    } else {
                        // 기존의 초성, 중성으로 한 글자 완성
                        ReplaceCompo(GetHanCode(cho, jung, 99));
                        FinishCompo();

                        // 이전 글자의 종성을 초성으로 하고 새로 입력된 중성과 조합하여 새 음절 분리
                        int newcho = jong;
                        ResetCompo();
                        cho = newcho;
                        jung = idx;
                        AppendCompo(GetHanCode(cho, jung, 99));
                    }
                } else {
                    // 자음이면 무조건 음절 분리
                    if (bConso) {
                        // 새로 입력된 초성으로 단독 글자 만듬
                        FinishCompo();
                        ResetCompo();
                        cho = idx;
                        AppendCompo(cho + 0x3131);
                        // 모음이면 복모음 하나 떼 와서 음절 분리
                    } else {
                        // 기존의 초성, 중성, 복자음 앞자로 한 글자 완성
                        ReplaceCompo(GetHanCode(cho, jung, GetLeftBokJa(jong)));

                        // 이전 글자의 복자음 뒷자를 초성으로 하고 새로 입력된 중성과 조합하여 새 음절 분리
                        FinishCompo();
                        int newcho = GetRightBokJa(jong);
                        ResetCompo();
                        cho = newcho;
                        jung = idx;
                        AppendCompo(GetHanCode(cho, jung, 99));
                    }
                }
                break;
        }
    }

    /**
     * 한글 삭제 처리 (역 한글 오토마타)
     */
    private void revKoreanAutomata() {

        Log.d(TAG, "State = " + GetHanState());

        switch(GetHanState()) {
            case H_NONE:
                keyDownUp(KeyEvent.KEYCODE_DEL);
                break;
            case H_CHO:
                if (!IsBokJa(cho)) {
                    ResetCompo();
                    getCurrentInputConnection().commitText("",0);
                } else {
                    // 복자음 초성인 경우 앞쪽 초성만 남김. ㄳ -> ㄱ
                    cho = GetLeftBokJa(cho);
                    ReplaceCompo(cho + 0x3131);
                }
                break;
            case H_JUNGONLY:
                // 단모임인 경우는 삭제
                if (!IsBokMo(jung)) {
                    ResetCompo();
                    keyDownUp(KeyEvent.KEYCODE_DEL);
                    // 복모음이면 앞쪽 모음만 남김. ㅘ -> ㅗ
                } else {
                    jung = GetLeftBokMo(jung);
                    ReplaceCompo(jung + 0x3131);
                }
                break;
            case H_JUNG:
                // 복모음이 아니면 모음 삭제하고 자음만 남긴다. 예:가 -> ㄱ
                if (!IsBokMo(jung)) {
                    ReplaceCompo(cho + 0x3131);
                    jung = 99;
                    // 복모음이면 뒤쪽 모음을 삭제한다. 예:와 -> 오
                } else {
                    jung = GetLeftBokMo(jung);
                    ReplaceCompo(GetHanCode(cho,jung,99));
                }
                break;
            case H_JONG:
                // 복자음이 아니면 받침 삭제한다. 예:간 -> 가
                if (!IsBokJa(jong)) {
                    ReplaceCompo(GetHanCode(cho, jung, 99));
                    jong = 99;
                    // 복자음 받침이면 뒤쪽 받침만 삭제한다. 예:닭 -> 달
                } else {
                    jong = GetLeftBokJa(jong);
                    ReplaceCompo(GetHanCode(cho,jung,jong));
                }
                break;
        }
    }

    // cho, jung, jong 값으로 한글 유니코드 음절 코드를 구한다.
    private int GetHanCode(int acho, int ajung, int ajong)
    {
        int choorder, jungorder, jongorder;

        choorder = hanattr[acho][1];
        if (ajung == 99) {
            jungorder = 99;
        } else {
            jungorder = ajung - 30;
        }

        if (ajong == 99) {
            jongorder = 99;
        } else {
            jongorder = hanattr[ajong][2];
        }

        // 유니코드 "가"자를 베이스로 초성만큼 거리 띄움
        int resultcode = 0xac00 + (choorder *21 * 28);

        // 중성이 있으면 중성만큼 띄움
        if (jungorder != 99) {
            resultcode += (jungorder * 28);
        }

        // 종성이 있으면 종성만큼 띄움
        if (jongorder != 99) {
            resultcode += jongorder;
        }

        return resultcode;
    }

    // 현재 한글 조립 상태를 조사한다.
    private int GetHanState() {
        // 초성이 없는 경우 - 아무것도 없거나 중성만 입력된 경우
        if (cho == 99) {
            if (jung == 99) {
                return H_NONE;
            } else {
                return H_JUNGONLY;
            }
        }

        // 초성은 있는데 중성이 없는 경우
        if (jung == 99) return H_CHO;

        // 중성이 있는데 종성이 없는 경우
        if (jong == 99) return H_JUNG;

        // 종성까지 다 입력된 경우
        return H_JONG;
    }

    // 복자음 테이블
    //첨자 0 : 원래 음소
    //첨자 2 : 새로 입력된 음소
    //첨자 3 : 대체될 음소
    private int arBokJa[][] = {
            {0,20,2},		// 앇
            {3,23,4},		// 앉
            {3,29,5},		// 않
            {8,0,9},		// 앍
            {8,16,10},		// 앎
            {8,17,11},		// 앏
            {8,20,12},		// 앐
            {8,27,13},		// 앑
            {8,28,14},		// 앒
            {8,29,15},		// 앓
            {17,20,19},		// 앖
    };

    //복자음인지 조사하여 순서값 리턴. 아니면 99 리턴
    private int findBokJa(int oldidx, int newidx) {
        int bokja = 99;
        for (int i=0;i<arBokJa.length;i++) {
            if (oldidx == arBokJa[i][0] && newidx == arBokJa[i][1]) {
                bokja = arBokJa[i][2];
                break;
            }
        }
        return bokja;
    }

    // 복자음인지 조사한다.
    private boolean IsBokJa(int code) {
        for (int i=0;i<arBokJa.length;i++) {
            if (code == arBokJa[i][2]) {
                return true;
            }
        }
        return false;
    }

    // 복자음의 왼쪽을 구한다.
    private int GetLeftBokJa(int code) {
        for (int i=0;i<arBokJa.length;i++) {
            if (code == arBokJa[i][2]) {
                return arBokJa[i][0];
            }
        }
        return 99;
    }

    // 복자음의 오른쪽을 구한다.
    private int GetRightBokJa(int code) {
        for (int i=0;i<arBokJa.length;i++) {
            if (code == arBokJa[i][2]) {
                return arBokJa[i][1];
            }
        }
        return 99;
    }

    // 복모음 테이블
    // 첨자 0 : 원래 음소
    // 첨자 2 : 새로 입력된 음소
    // 첨자 3 : 대체될 음소
    private int[][] arBokMo = {
            {30,30,32},		// ㅏ+ㅏ=ㅑ
            {34,34,36},		// ㅓ+ㅓ=ㅕ
            {38,38,42},		// ㅗ+ㅗ=ㅛ
            {43,43,47},		// ㅜ+ㅜ=ㅠ
            {35,35,37},		// ㅔ+ㅔ=ㅖ
            {31,31,33},		// ㅐ+ㅐ=ㅒ
            {38,30,39},		// ㅗ+ㅏ=ㅘ
            {38,50,41},		// ㅗ+ㅣ=ㅚ
            {43,34,44},		// ㅜ+ㅓ=ㅝ
            {43,50,46},		// ㅜ+ㅣ=ㅟ
            {38,31,40},		// ㅗ+ㅐ=ㅙ
            {43,35,45},		// ㅜ+ㅔ=ㅞ
            {48,50,49},		// ㅡ+ㅣ=ㅢ
    };

    //복모음인지 조사하여 순서값 리턴. 아니면 99 리턴
    private int findBokMo(int oldidx, int newidx) {
        int bokmo = 99;
        for (int i=0;i<arBokMo.length;i++) {
            if (oldidx == arBokMo[i][0] && newidx == arBokMo[i][1]) {
                bokmo = arBokMo[i][2];
                break;
            }
        }
        return bokmo;
    }

    // 복자음인지 조사한다.
    private boolean IsBokMo(int code) {
        for (int i=0;i<arBokMo.length;i++) {
            if (code == arBokMo[i][2]) {
                return true;
            }
        }
        return false;
    }

    // 복자음의 왼쪽을 구한다.
    private int GetLeftBokMo(int code) {
        for (int i=0;i<arBokMo.length;i++) {
            if (code == arBokMo[i][2]) {
                return arBokMo[i][0];
            }
        }

        return 99;
    }

    // 복자음의 오른쪽을 구한다.
    private int GetRightBokMo(int code) {
        for (int i=0;i<arBokMo.length;i++) {
            if (code == arBokMo[i][2]) {
                return arBokMo[i][0];
            }
        }

        return 99;
    }

    //한글 입력기의 상태 변수값을 초기화한다.
    private void ResetCompo()
    {
        cho = jung = jong = 99;
        mComp.setLength(0);
    }

    // 조립문자열 뒤에 추가
    private void AppendCompo(int code) {
        InputConnection ime = getCurrentInputConnection();
        mComp.append((char)code);
        ime.setComposingText(mComp, 1);
    }

    // 조립 문자열 대체
    private void ReplaceCompo(int code) {
        InputConnection ime = getCurrentInputConnection();
        mComp.setCharAt(0, (char)code);
        ime.setComposingText(mComp, 1);
    }

    // 조립 중인 문자열 확정
    private void FinishCompo() {
        InputConnection ime = getCurrentInputConnection();
        ime.finishComposingText();
    }

    /**
     * Message 서비스 시작
     */
    private void startMsgService() {
        Log.d(TAG, "startMsgService() : start Message service");

        bindService(new Intent(this, com.klasis.overhand.service.Message.class), msgServiceConn, Context.BIND_AUTO_CREATE);
    }

    /**
     * Message 서비스 확인
     */
    private boolean checkMsgService() {
        Log.d(TAG, "checkMsgService() : start (check)");

        // Message 서비스 확인
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> procinfo = am.getRunningServices(100);
        for(int i = 0; i < procinfo.size(); i++) {
            if (procinfo.get(i).service.getClassName().equals(getString(R.string.message_service)))
                return true;
        }

        return false;
    }

    /**
     * Message 서비스 연결
     */
    private ServiceConnection msgServiceConn = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Log.d(TAG, "msgServiceConn : Message Service connected");

            // Messsage Service 초기화
            msgService = ((com.klasis.overhand.service.Message.MessageBinder) iBinder).getService();

            // 통신을 위해 MessageHandler 정보 전달
            msgHandler = msgService.getMessageHandler();

            // 통신을 위해 KeyHandler 정보 전달
            msgService.setKeyHandler(keyHandler);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.d(TAG, "msgServiceConn : Message Service disconnected");

            msgService = null;
            keyHandler = null;
       }
    };

    public class KeyHandler extends Handler {

        @Override
        public void handleMessage(Message msg) {
            Log.d(TAG, "KeyHandler : handleMessage() - Message(" + msg.what + "), Data(" + msg.arg1 + ")");

            switch (msg.what) {
                // 키 값 전송받음
                case Constants.MESSAGE_KEY_SEND_KEYVALUE:
                    // 키 분석 및 입력 처리
                    keyService(msg.arg1);
                    break;
            }

            super.handleMessage(msg);
        }
    }
}
