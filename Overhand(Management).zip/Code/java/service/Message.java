package com.klasis.overhand.service;

import com.klasis.overhand.bluetooth.*;
import com.klasis.overhand.utils.AppSettings;
import com.klasis.overhand.utils.Constants;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

/**
 * Overhand 장치의 메세지 발신 및 수신 서비스
 * Created by klasis on 2017-08-16.
 */

public class Message extends Service {

    // Debugging
    private static final String TAG = "Message";

    // Context, System
    private Context context = null;
    private static Handler activityHandler = null;
    private MessageHandler messageHandler = new MessageHandler();
    private final IBinder binder = new MessageBinder();
    private Handler keyHandler = null;
    private Handler optimizeHandler = null;

    // Bluetooth
    private BluetoothAdapter bluetoothAdapter = null;       // local Bluetooth adapter managed by Android Framework
    private BleManager bleManager = null;
    private ConnectionInfo connectionInfo = null;           // Remembers connection info when BT connection is made

    private boolean init_settings = false;


    /*****************************************************
     *	Overrided methods
     ******************************************************/

    @Override
    public void onCreate() {
        Log.d(TAG, "# Message Service - onCreate() : start");

        initializeService();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "# Message Service - onStartCommand() : start");

        // If service returns START_STICKY, android restarts service automatically after forced close.
        // At this time, onStartCommand() method in service must handle null intent.
        // Service.START_STICKY와 동일
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "# Message Service - onBind() : start");
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "# Message Service - onUnbind() : start");
        return true;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "# Message Service - onDestroy() : start");
        finalizeService();
    }

    @Override
    public void onLowMemory(){
        Log.d(TAG, "# Message Service - onLowMemory() : start");
        // onDestroy is not always called when applications are finished by Android system.
        finalizeService();
    }

    private void initializeService() {
        Log.d(TAG, "# Message Service - initializeService() : start");

        // 초기화
        context = getApplicationContext();                                          // Context 초기화
        AppSettings.initializeSettings(context);                                    // AppSettings 초기화

        if (bluetoothAdapter == null)
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();                // Bluetooth adapter 초기화
        if (bleManager == null)
            bleManager = BleManager.getInstance(messageHandler);                    // BluetoothManager 초기화

        // 서비스 모니터링 시작
        startServiceMonitoring();

        // 인스턴스 생성
        connectionInfo = ConnectionInfo.getInstance(context);                       // ConnectionInfo 인스턴스 생성
    }

    public void finalizeService() {
        Log.d(TAG, "# Message Service - finalizeService() : start");

        // Stop the bluetooth session
        bluetoothAdapter = null;
        if (bleManager != null) {
            bleManager.disconnect();
//            bleManager.finalize();
        }
        bleManager = null;
    }

    /**
     * Setting up bluetooth connection
     * @param handler   MainActivity의 ActivityHandler
     */
    public void setupService(Handler handler) {
        activityHandler = handler;

        // BleManager 인스턴스 중복 확인
        if (bleManager == null)
            bleManager = BleManager.getInstance(messageHandler);

        // If ConnectionInfo holds previous connection info,
        // try to connect using it.
        if (connectionInfo.getDeviceAddress() != null && connectionInfo.getDeviceName() != null) {
            connectDevice(connectionInfo.getDeviceAddress());
        }
    }

    /**
     * Overhand 장치로 메세지 전송
     * @param type      메세지의 헤더 중 메세지 유형
     * @param target    메세지의 헤더 중 메세지 타켓
     * @param data      메세지의 데이터 중 데이터
     */
    public void sendMessage(int type, int target, int data) {
        Log.d(TAG, "sendMessage() : message - type(" + type + "), target(" + target + "), data(" + data + ")");
        // Overhand 프로토콜 메세지로 변환
        byte[] message = OHPManager.send(type, target, data);

        Log.d(TAG, "sendMessage() : OHP message(" + message[0] + "), (" + message[1] + "), (" + message[2] + "), (" + message[3] + ")");

        if (bleManager != null) {
            if (bleManager.getState() == BleManager.STATE_CONNECTED) {
                // Check that there's actually something to send
                if (message.length > 0) {
                    // Get the message bytes and tell the BleManager to write
                    bleManager.write(null, message);
                }
            } else {
                Log.e(TAG, "sendMessage() : Sending Message errors because of BLE NOT connected");
                // mHandler.obtainMessage(Constants.MESSAGE_CMD_ERROR_NOT_CONNECTED).sendToTarget();
            }
        } else {
            Log.e(TAG, "sendMessage() : BleManager is null");
        }
    }

    /**
     * Overhand 장치로 메세지 전송
     * @param type      메세지의 헤더 중 메세지 유형
     * @param target    메세지의 헤더 중 메세지 타켓
     * @param data      메세지의 데이터 중 데이터
     */
    public void sendMessage(int type, int target, int data, boolean init) {
        Log.d(TAG, "sendMessage() : message - type(" + type + "), target(" + target + "), data(" + data + ")");

        init_settings = init;

        // Overhand 프로토콜 메세지로 변환
        byte[] message = OHPManager.send(type, target, data);

        Log.d(TAG, "sendMessage() : OHP message(" + message[0] + "), (" + message[1] + "), (" + message[2] + "), (" + message[3] + ")");

        if (bleManager != null) {
            if (bleManager.getState() == BleManager.STATE_CONNECTED) {
                // Check that there's actually something to send
                if (message.length > 0) {
                    // Get the message bytes and tell the BleManager to write
                    bleManager.write(null, message);
                }
            } else {
                Log.e(TAG, "sendMessage() : Sending Message errors because of BLE NOT connected");
                // mHandler.obtainMessage(Constants.MESSAGE_CMD_ERROR_NOT_CONNECTED).sendToTarget();
            }
        } else {
            Log.e(TAG, "sendMessage() : BleManager is null");
        }
    }

    /**
     * Overhand 장치로부터 메세지 수신
     * @param msg       수신 메세지
     */
    public void receiveMessage(android.os.Message msg) {
        // 메세지로부터 Overhand 프로토콜 추출
        OverhandProtocol ohp = null;
        ohp = OHPManager.read(msg.arg1);

        // Overhand 프로토콜 분석
        Log.d(TAG, "# Message Service - receiveMessage() : The message is type(" + ohp.getMsgType() + "), target(" + ohp.getMsgTarget() + "), data(" + ohp.getMsgData() + ")");

        switch (ohp.getMsgType()) {
            case Constants.OHP_TYPE_REQUEST:
                switch (ohp.getMsgTarget()) {
                    case Constants.OHP_TARGET_FINGER1:
                        // 검지 압력 센서 값 불러오기 및 변환 및 응답
                        sendMessage(Constants.OHP_TYPE_RESPONSE, Constants.OHP_TARGET_FINGER1, AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER1), true));
                        break;

                    case Constants.OHP_TARGET_FINGER2:
                        // 검지 압력 센서 값 불러오기 및 변환 및 응답
                        sendMessage(Constants.OHP_TYPE_RESPONSE, Constants.OHP_TARGET_FINGER2, AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER2), true));
                        break;

                    case Constants.OHP_TARGET_FINGER3:
                        // 중지 압력 센서 값 불러오기 및 변환 및 응답
                        sendMessage(Constants.OHP_TYPE_RESPONSE, Constants.OHP_TARGET_FINGER3, AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER3), true));
                        break;

                    case Constants.OHP_TARGET_FINGER4:
                        // 약지 압력 센서 값 불러오기 및 변환 및 응답
                        sendMessage(Constants.OHP_TYPE_RESPONSE, Constants.OHP_TARGET_FINGER4, AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER4), true));
                        break;

                    case Constants.OHP_TARGET_FINGER5:
                        // 소지 압력 센서 값 불러오기 및 변환 및 응답
                        sendMessage(Constants.OHP_TYPE_RESPONSE, Constants.OHP_TARGET_FINGER5, AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER5), true));
                        break;

                    case Constants.OHP_TARGET_GYRO:
                        // 자이로 센서 값 불러오기 및 변환 및 응답
                        sendMessage(Constants.OHP_TYPE_RESPONSE, Constants.OHP_TARGET_GYRO, AppSettings.convertSettings(Constants.CVT_GYRO_SENSOR, AppSettings.loadSettings(Constants.PREFERENCE_KEY_GYRO), true));
                        break;

                    case Constants.OHP_TARGET_SLEEP:
                        // 절전 모드 값 불러오기 및 변환 및 응답
                        sendMessage(Constants.OHP_TYPE_RESPONSE, Constants.OHP_TARGET_SLEEP, AppSettings.convertSettings(Constants.CVT_SLEEP_MODE, AppSettings.loadSettings(Constants.PREFERENCE_KEY_SLEEP_MODE), true));
                        break;

                    default:
                        Log.e(TAG, "# Message Service - receiveMessage() : Message Target of OHP_TYPE_REQUEST is " + String.valueOf(ohp.getMsgTarget()));
                        break;
                }
                break;

            case Constants.OHP_TYPE_RESPONSE:
                switch (ohp.getMsgTarget()) {
                    case Constants.OHP_TARGET_FINGER1:
                        if (!init_settings) {
                            // OptimizeHanlder로 메세지 전송
                            optimizeHandler.sendMessage(android.os.Message.obtain(optimizeHandler, Constants.MESSAGE_OPT_FINGER1, ohp.getMsgData(), 0));
                        }
                        else {
                            Log.d(TAG, "# Message Service - receiveMessage() : Initial value Finger1(" + ohp.getMsgData() + ") [" + init_settings + "]");
                            // Initial settings 설정
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER1, ohp.getMsgData());
                        }
                        break;

                    case Constants.OHP_TARGET_FINGER2:
                        if (!init_settings) {
                            // OptimizeHanlder로 메세지 전송
                            optimizeHandler.sendMessage(android.os.Message.obtain(optimizeHandler, Constants.MESSAGE_OPT_FINGER2, ohp.getMsgData(), 0));
                        }
                        else {
                            Log.d(TAG, "# Message Service - receiveMessage() : Initial value Finger2(" + ohp.getMsgData() + ") [" + init_settings + "]");
                            // Initial settings 설정
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER2, ohp.getMsgData());
                        }
                        break;

                    case Constants.OHP_TARGET_FINGER3:
                        if (!init_settings) {
                            // OptimizeHanlder로 메세지 전송
                            optimizeHandler.sendMessage(android.os.Message.obtain(optimizeHandler, Constants.MESSAGE_OPT_FINGER3, ohp.getMsgData(), 0));
                        }
                        else {
                            Log.d(TAG, "# Message Service - receiveMessage() : Initial value Finger3(" + ohp.getMsgData() + ") [" + init_settings + "]");
                            // Initial settings 설정
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER3, ohp.getMsgData());
                        }
                        break;

                    case Constants.OHP_TARGET_FINGER4:
                        if (!init_settings) {
                            // OptimizeHanlder로 메세지 전송
                            optimizeHandler.sendMessage(android.os.Message.obtain(optimizeHandler, Constants.MESSAGE_OPT_FINGER4, ohp.getMsgData(), 0));
                        }
                        else {
                            Log.d(TAG, "# Message Service - receiveMessage() : Initial value Finger4(" + ohp.getMsgData() + ") [" + init_settings + "]");
                            // Initial settings 설정
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER4, ohp.getMsgData());
                        }
                        break;

                    case Constants.OHP_TARGET_FINGER5:
                        if (!init_settings) {
                            // OptimizeHanlder로 메세지 전송
                            optimizeHandler.sendMessage(android.os.Message.obtain(optimizeHandler, Constants.MESSAGE_OPT_FINGER5, ohp.getMsgData(), 0));
                        }
                        else {
                            Log.d(TAG, "# Message Service - receiveMessage() : Initial value Finger5(" + ohp.getMsgData() + ") [" + init_settings + "]");
                            // Initial settings 설정
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER5, ohp.getMsgData());
                            sendMessage(Constants.OHP_TYPE_REQUEST, Constants.OHP_TARGET_GYRO, 0, true);
                        }
                        break;

                    case Constants.OHP_TARGET_GYRO:
                        Log.d(TAG, "# Message Service - receiveMessage() : Initial value Gyro(" + ohp.getMsgData() + ") [" + init_settings + "]");
                        // Initial settings 설정
                        AppSettings.saveSettings(Constants.PREFERENCE_KEY_GYRO, ohp.getMsgData());
                        sendMessage(Constants.OHP_TYPE_REQUEST, Constants.OHP_TARGET_SLEEP, 0, true);
                        break;

                    case Constants.OHP_TARGET_SLEEP:
                        Log.d(TAG, "# Message Service - receiveMessage() : Initial value Sleep(" + ohp.getMsgData() + ") [" + init_settings + "]");
                        // Initial settings 설정
                        AppSettings.saveSettings(Constants.PREFERENCE_KEY_SLEEP_MODE, ohp.getMsgData());
                        activityHandler.sendMessage(android.os.Message.obtain(activityHandler, Constants.INITIAL_SETTINGS, 0, 0));
                        break;

                    default:
                        Log.e(TAG, "# Message Service - receiveMessage() :  Message Target of OHP_TYPE_RESPONSE is " + String.valueOf(ohp.getMsgTarget()));
                        break;
                }
                break;

            case Constants.OHP_TYPE_SEND:
                switch (ohp.getMsgTarget()) {
                    case Constants.OHP_TARGET_PRESSURE:
                    case Constants.OHP_TARGET_GYRO:
                        // 키 입력
                        if (keyHandler == null)
                            Log.e(TAG, "# Message Service - receiveMessage() : keyHandler is null");
                        else {
                            // Key Service로 값 전달
                            keyHandler.sendMessage(android.os.Message.obtain(keyHandler, Constants.MESSAGE_KEY_SEND_KEYVALUE, ohp.getMsgData(), 0));
                        }
                        break;

                    default:
                        Log.e(TAG, "# Message Service - receiveMessage() : Message Target of OHP_TYPE_SEND is " + String.valueOf(ohp.getMsgTarget()));
                        break;
                }
                break;

            default:
                Log.e(TAG, "# Message Service - receiveMessage() : Message Type is " + String.valueOf(ohp.getMsgType()));
                break;
        }
    }

    /**
     * 블루투스 장치 연결
     * @param address       사용자가 선택한 블루투스 장치의 MAC 주소
     */
    public void connectDevice(String address) {
        if(address != null && bleManager != null) {
            bleManager.disconnect();

            // 블루투스 장치 연결 요청
            if(bleManager.connectGatt(context, true, address)) {
                // 연결된 장치 정보 저장
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
                connectionInfo.setDeviceAddress(address);
                connectionInfo.setDeviceName(device.getName());
            }
        }
    }

    /**
     * 블루투스 연결 해제
     */
    public void disconnectDevice() {
        bleManager.disconnect();
    }

    /**
     * Get connected device name
     */
    public String getDeviceName() {
        return connectionInfo.getDeviceName();
    }

    /**
     * Start service monitoring. Service monitoring prevents
     * unintended close of service.
     */
    public void startServiceMonitoring() {
        if(AppSettings.getBgService()) {
            ServiceMonitoring.startMonitoring(context);
        } else {
            ServiceMonitoring.stopMonitoring(context);
        }
    }

    /**
     * 최적화 Activity와의 통신을 위해 OptimizeHanlder를 저장
     * @param handler       OptimizeHanlder 객체
     */
    public void setOptimizeHandler(Handler handler) {
        Log.d(TAG, "setOptimizeHandler() : set OptimizeHanlder");

        optimizeHandler = handler;
    }

    /**
     * Key 서비스와 통신을 위해 KeyHandler를 저장
     * @param handler       KeyHandelr 객체
     */
    public void setKeyHandler(Handler handler) {
        Log.d(TAG, "setKeyHandler() : set KeyHandler");

        keyHandler = handler;
    }

    /**
     * Key 서비스와 통신을 위해 MessageHandler를 전달
     * @return
     */
    public MessageHandler getMessageHandler() {
        return messageHandler;
    }

    public class MessageBinder extends Binder {
        public Message getService() {
            return Message.this;
        }
    }

    class MessageHandler extends Handler {
        @Override
        public void handleMessage(android.os.Message msg) {
            Log.d(TAG, "# Message Service - MessageHandler : handleMessage() - Message(" + msg.what + ")");

            switch (msg.what) {
                // 블루투스 상태 변화
                case BleManager.MESSAGE_STATE_CHANGE:
                    Log.d(TAG, "# Message Service - MessageHandler : MESSAGE_STATE_CHANGE(" + msg.arg1 + ")");

                    switch (msg.arg1) {
                        case BleManager.STATE_NONE:
                            activityHandler.obtainMessage(Constants.MESSAGE_BT_STATE_INITIALIZED).sendToTarget();
                            break;

                        case BleManager.STATE_CONNECTING:
                            activityHandler.obtainMessage(Constants.MESSAGE_BT_STATE_CONNECTING).sendToTarget();
                            break;

                        case BleManager.STATE_CONNECTED:
                            activityHandler.obtainMessage(Constants.MESSAGE_BT_STATE_CONNECTED).sendToTarget();
                            break;

                        case BleManager.STATE_IDLE:
                            activityHandler.obtainMessage(Constants.MESSAGE_BT_STATE_INITIALIZED).sendToTarget();
                            break;
                    }
                    break;

//                // 메세지 발신
//                case BleManager.MESSAGE_WRITE:
//                    Log.d(TAG, "# Message Service - MessageHandler : MESSAGE_WRITE");
//                    String message = (String) msg.obj;
//                    if(message != null && message.length() > 0)
//                        sendMessageToDevice(message.getBytes());
//                    break;

                // 메세지 수신
                case BleManager.MESSAGE_READ:
                    Log.d(TAG, "# Message Service - MessageHandler : MESSAGE_READ");
                    receiveMessage(msg);
                    break;
            }

            super.handleMessage(msg);
        }
    }
}
