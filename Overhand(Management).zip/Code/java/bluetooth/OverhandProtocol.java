package com.klasis.overhand.bluetooth;

/**
 * Created by Klasis on 2017-08-28.
 */

public class OverhandProtocol {

    private int msgType;                         // 4-bit의 메세지 유형
    private int msgTarget;                       // 4-bit의 메세지 타겟
    private int msgData;                         // 24-bit의 메세지 내용 (3-byte)

    public OverhandProtocol() {
        this.msgType = -1;
        this.msgTarget = -1;
        this.msgData = -1;
    }

    public OverhandProtocol(int msgType, int msgTarget, int data) {
        this.msgType = msgType;
        this.msgTarget = msgTarget;
        this.msgData = data;
    }

    public void setMsgType(int msgType) {
        this.msgType = msgType;
    }

    public void setMsgTarget(int msgTarget) {
        this.msgTarget = msgTarget;
    }

    public void setMsgData(int msgData) {
        this.msgData = msgData;
    }

    public int getMsgType() {
        return this.msgType;
    }

    public int getMsgTarget() {
        return this.msgTarget;
    }

    public int getMsgData() {
        return this.msgData;
    }
}