package com.klasis.overhand.bluetooth;

import android.util.Log;

/**
 * Overhand 장치와 앱 간의 통신 프로토콜
 * Created by Klasis on 2017-08-28.
 */

public class OHPManager {

    // Debugging
    private final static String TAG = "OHPManager";

    /**
     * 오버핸드 프로토콜에 따른 메세지 전송
     * @param type      메세지의 헤더 중 메세지 유형
     * @param target    메세지의 헤더 중 메세지 타켓
     * @param data      메세지의 데이터 중 데이터
     */
    public static byte[] send(int type, int target, int data) {
        // 메세지 객체(4-byte) 생성 및 초기화
        byte[] msg = new byte[4];

        // 메세지 헤더 및 내용 삽입
        msg[0] = (byte)((type << 4) | target);		// 메세지의 상위 1-byte에 헤더(메세지 유형, 메세지 타겟) 삽입
        msg[1] = (byte)(data >> 8);					// 메세지의 하위 3-byte에 데이터(상위-byte) 삽입 (하위 1-byte 공백 제외)
        msg[2] = (byte)(data & 255);				// 메세지의 하위 3-byte에 데이터(하위-byte) 삽입 (하위 1-byte 공백 제외)
        msg[3] = 0;									// 메세지의 하위 1-byte에 공백 추가

        return msg;
    }

    /**
     * 오버핸드 프로토콜에 따른 메세지의 헤더 및 데이터 추출
     * @return          Overhand 프로토콜로 메세지 반환
     */
    public static OverhandProtocol read(int msg) {
        // 메세지(4-byte) 생성 및 초기화

        Log.d(TAG, "read() : The message(String->byte[]) is message(" +  + (msg & 0xFF000000) + ")(" + (msg & 0x00FF0000) + ")(" + (msg & 0x0000FF00) + ")(" + (msg & 0x000000FF) + ")");

        // 메세지 헤더 및 데이터 추출
        int type = (msg >> 28) & 0x0000000F;                // 메세지의 상위 1-byte 헤더(상위 4-bit 메세지 유형) 추출
        int target = (msg >> 24) & 0x0000000F;	            // 메세지의 상위 1-byte 헤더(하위 4-bit 메세지 타겟) 추출
        int data = (msg >> 8) & 0x0000FFFF;                 // 메세지의 하위 3-byte 데이터 추출 (하위 1-byte 공백 제거)

        // Overhand 프로토콜로 메세지 반환
        return new OverhandProtocol(type, target, data);
    }
}
