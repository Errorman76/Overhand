package com.klasis.overhand.bluetooth;

import com.klasis.overhand.R;
import com.klasis.overhand.utils.Constants;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Bluetooth LE 관리 클래스
 * Created by klasis on 2017-08-10.
 */

public class BleManager {

    // Debugging
    private static final String TAG = "BleManager";

    // Bluetooth connection state
    public static final int STATE_ERROR = -1;               // Error
    public static final int STATE_NONE = 0;                 // Initialized
    public static final int STATE_IDLE = 1;                 // Not connected
    public static final int STATE_SCANNING = 2;             // Scanning
    public static final int STATE_CONNECTING = 13;          // Connecting
    public static final int STATE_CONNECTED = 16;           // Connected

    // Message types sent from the BluetoothManager to Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;

    private static final long SCAN_PERIOD = 5*1000;         // Stops scanning after a pre-defined scan period.

    // System, Management
    private static BleManager bleManager = null;		    // Singleton pattern
    private static BluetoothLeScanner bleScanner = null;
    private final Handler bleHandler;

    // Bluetooth
    private final BluetoothAdapter btAdapter;
    private ScanCallback scanCallback = null;

    private BluetoothDevice defaultDevice = null;

    private BluetoothGatt bluetoothGatt = null;

    private ArrayList<BluetoothGattService> gattServices = new ArrayList<>();
    private ArrayList<BluetoothGattCharacteristic> gattCharacteristics = new ArrayList<>();
    private ArrayList<BluetoothGattCharacteristic> writableCharacteristics = new ArrayList<>();
    private BluetoothGattCharacteristic defaultChar = null;

    // Parameters
    private int state = -1;

    /**
     * A new Bluetooth session.
     * @param handler   A Listener to receive messages back to the UI Activity.
     */
    private BleManager(Handler handler) {
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        state = STATE_NONE;
        bleHandler = handler;
        bleScanner = btAdapter.getBluetoothLeScanner();
    }

    public synchronized static BleManager getInstance(Handler handler) {
        if (bleManager == null) {
            bleManager = new BleManager(handler);
        }
        return bleManager;
    }

    public synchronized void finalize() {
        // Make sure we're not doing discovery anymore
        if (btAdapter != null) {
            state = STATE_IDLE;
            bleScanner.stopScan(scanCallback);
            disconnect();
        }

        defaultDevice = null;
        bluetoothGatt = null;
        gattServices.clear();
        gattCharacteristics.clear();
        writableCharacteristics.clear();

/*        if(context == null)
            return;

        // Don't forget this!!
        // Unregister broadcast listeners
		context.unregisterReceiver(mReceiver);*/
    }

    private void stopScanning() {
        if(state < STATE_CONNECTING) {
            state = STATE_IDLE;
            bleHandler.obtainMessage(MESSAGE_STATE_CHANGE, STATE_IDLE, 0).sendToTarget();
        }
        bleScanner.stopScan(scanCallback);
    }

    /**
     * Check services and looking for writable characteristics
     */
    private int checkGattServices(List<BluetoothGattService> btGattServices) {
        if (btAdapter == null || bluetoothGatt == null) {
            Log.d(TAG, "checkGattServices() : btAdapter not initialized");
            return -1;
        }

        for (BluetoothGattService gattService : btGattServices) {
            // Default service info
            Log.d(TAG, "checkGattServices() : GATT Service: "+gattService.toString());

            // Remember service
            gattServices.add(gattService);

            // Extract characteristics
            List<BluetoothGattCharacteristic> btGattCharacteristics = gattService.getCharacteristics();
            for (BluetoothGattCharacteristic gattCharacteristic : btGattCharacteristics) {
                // Remember characteristic
                gattCharacteristics.add(gattCharacteristic);
                Log.d(TAG, "checkGattServices() : GATT Char: "+gattCharacteristic.toString());

                boolean isWritable = isWritableCharacteristic(gattCharacteristic);
                if(isWritable) {
                    writableCharacteristics.add(gattCharacteristic);
                }

                boolean isReadable = isReadableCharacteristic(gattCharacteristic);
                if(isReadable) {
                    readCharacteristic(gattCharacteristic);
                }

                if(isNotificationCharacteristic(gattCharacteristic)) {
                    setCharacteristicNotification(gattCharacteristic, true);
                    if(isWritable && isReadable) {
                        defaultChar = gattCharacteristic;
                    }
                }
            }
        }

        return writableCharacteristics.size();
    }

    private boolean isWritableCharacteristic(BluetoothGattCharacteristic chr) {
        if(chr == null) return false;

        final int charaProp = chr.getProperties();
        if (((charaProp & BluetoothGattCharacteristic.PROPERTY_WRITE) |
                (charaProp & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) > 0) {
            Log.d(TAG, "# Found writable characteristic");
            return true;
        } else {
            Log.d(TAG, "# Not writable characteristic");
            return false;
        }
    }

    private boolean isReadableCharacteristic(BluetoothGattCharacteristic chr) {
        if(chr == null) return false;

        final int charaProp = chr.getProperties();
        if((charaProp & BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
            Log.d(TAG, "isWritableCharacteristic() : Found readable characteristic");
            return true;
        } else {
            Log.d(TAG, "isWritableCharacteristic() : Not readable characteristic");
            return false;
        }
    }

    private boolean isNotificationCharacteristic(BluetoothGattCharacteristic chr) {
        if(chr == null) return false;

        final int charaProp = chr.getProperties();
        if((charaProp & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
            Log.d(TAG, "isNotificationCharacteristic() : Found notification characteristic");
            return true;
        } else {
            Log.d(TAG, "isNotificationCharacteristic() : Not notification characteristic");
            return false;
        }
    }

    /**
     * Request a read on a given {@code BluetoothGattCharacteristic}. The read result is reported
     * asynchronously through the {@code BluetoothGattCallback#onCharacteristicRead(android.bluetooth.BluetoothGatt, android.bluetooth.BluetoothGattCharacteristic, int)}
     * callback.
     *
     * @param characteristic The characteristic to read from.
     */
    public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (btAdapter == null || bluetoothGatt == null) {
            Log.d(TAG, "readCharacteristic() : btAdapter not initialized");
            return;
        }
        bluetoothGatt.readCharacteristic(characteristic);
    }

    /**
     * Enables or disables notification on a give characteristic.
     *
     * @param characteristic Characteristic to act on.
     * @param enabled If true, enable notification.  False otherwise.
     */
    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic,
                                              boolean enabled) {
        if (btAdapter == null || bluetoothGatt == null) {
            Log.d(TAG, "setCharacteristicNotification() : btAdapter not initialized");
            return;
        }
        bluetoothGatt.setCharacteristicNotification(characteristic, enabled);
    }


    /*********************************************************************************************
     *	Public methods
     *********************************************************************************************/

    public void setLeScanCallback(ScanCallback scanCallback) {
        this.scanCallback = scanCallback;
    }

    public int getState() {
        return state;
    }

    public boolean scanLeDevice(final boolean enable) {
        boolean isScanStarted = false;

        if (enable) {
            if (state == STATE_SCANNING)
                return false;

            bleScanner.startScan(scanCallback);
            state = STATE_SCANNING;

            // Stops scanning after a pre-defined scan period.
            bleHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    stopScanning();
                }
            }, SCAN_PERIOD);

            bleHandler.obtainMessage(MESSAGE_STATE_CHANGE, STATE_SCANNING, 0).sendToTarget();
            isScanStarted = true;
        }
        else {
            if(state < STATE_CONNECTING) {
                state = STATE_IDLE;
                bleHandler.obtainMessage(MESSAGE_STATE_CHANGE, STATE_IDLE, 0).sendToTarget();
            }
            stopScanning();
        }

        return isScanStarted;
    }

    public boolean connectGatt(Context c, boolean bAutoReconnect, BluetoothDevice device) {
        if(c == null || device == null)
            return false;

        gattServices.clear();
        gattCharacteristics.clear();
        writableCharacteristics.clear();

        bluetoothGatt = device.connectGatt(c, bAutoReconnect, mGattCallback);
        defaultDevice = device;

        state = STATE_CONNECTING;
        bleHandler.obtainMessage(MESSAGE_STATE_CHANGE, STATE_CONNECTING, 0).sendToTarget();
        return true;
    }

    public boolean connectGatt(Context c, boolean bAutoReconnect, String address) {
        if(c == null || address == null)
            return false;

        if(bluetoothGatt != null && defaultDevice != null
                && address.equals(defaultDevice.getAddress())) {
            if (bluetoothGatt.connect()) {
                state = STATE_CONNECTING;
                return true;
            }
        }

        BluetoothDevice device =
                BluetoothAdapter.getDefaultAdapter().getRemoteDevice(address);
        if (device == null) {
            Log.d(TAG, "BluetoothDevice : Device not found.  Unable to connect.");
            return false;
        }

        gattServices.clear();
        gattCharacteristics.clear();
        writableCharacteristics.clear();

        bluetoothGatt = device.connectGatt(c, bAutoReconnect, mGattCallback);
        defaultDevice = device;

        state = STATE_CONNECTING;
        bleHandler.obtainMessage(MESSAGE_STATE_CHANGE, STATE_CONNECTING, 0).sendToTarget();
        return true;
    }

    /**
     * Disconnects an existing connection or cancel a pending connection. The disconnection result
     * is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public void disconnect() {
        if (btAdapter == null || bluetoothGatt == null) {
            Log.d(TAG, "disconnect() : btAdapter not initialized");
            return;
        }
        bluetoothGatt.disconnect();
    }

    public boolean write(BluetoothGattCharacteristic chr, byte[] data) {
        if (bluetoothGatt == null) {
            Log.d(TAG, "write() : BluetoothGatt not initialized");
            return false;
        }

        BluetoothGattCharacteristic writableChar = null;

        if(chr == null) {
            if(defaultChar == null) {
                for(BluetoothGattCharacteristic bgc : writableCharacteristics) {
                    if(isWritableCharacteristic(bgc)) {
                        writableChar = bgc;
                    }
                }
                if(writableChar == null) {
                    Log.d(TAG, "write() : Write failed - No available characteristic");
                    return false;
                }
            } else {
                if(isWritableCharacteristic(defaultChar)) {
                    Log.d(TAG, "write() : Default GattCharacteristic is PROPERY_WRITE | PROPERTY_WRITE_NO_RESPONSE");
                    writableChar = defaultChar;
                } else {
                    Log.d(TAG, "write() : Default GattCharacteristic is not writable");
                    defaultChar = null;
                    return false;
                }
            }
        } else {
            if (isWritableCharacteristic(chr)) {
                Log.d(TAG, "write() : user GattCharacteristic is PROPERY_WRITE | PROPERTY_WRITE_NO_RESPONSE");
                writableChar = chr;
            } else {
                Log.d(TAG, "write() : user GattCharacteristic is not writable");
                return false;
            }
        }

        writableChar.setValue(data);
        writableChar.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
        bluetoothGatt.writeCharacteristic(writableChar);
        defaultChar = writableChar;
        return true;
    }

    public void setWritableCharacteristic(BluetoothGattCharacteristic chr) {
        defaultChar = chr;
    }

    public ArrayList<BluetoothGattService> getServices() {
        return gattServices;
    }

    public ArrayList<BluetoothGattCharacteristic> getCharacteristics() {
        return gattCharacteristics;
    }

    public ArrayList<BluetoothGattCharacteristic> getWritableCharacteristics() {
        return writableCharacteristics;
    }

    /**
     * Check the device that is connected with Overhand.
     * @param activity      Activity
     * @return              true : Bluetooth is connected / false : Bluetooth is NOT connected
     */
    public static boolean checkBluetooth(Activity activity) {
        Log.d(TAG, "checkBluetooth() : checking");

        // Check the device that supports BLE.
        if (!activity.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Log.e(TAG, "Bluetooth LE is not supported on the device.");
            Toast.makeText(activity, R.string.bt_ble_not_supported, Toast.LENGTH_SHORT).show();
            return false;
        }

        // Check the device that supports Bluetooth.
        if (BluetoothAdapter.getDefaultAdapter() == null) {
            Log.e(TAG, "Bluetooth is not supported on the device.");
            Toast.makeText(activity, R.string.bt_bt_not_supported, Toast.LENGTH_SHORT).show();
            return false;
        }

        // Check the Bluetooth that is activated on the device.
        if (!BluetoothAdapter.getDefaultAdapter().isEnabled()) {
            Log.d(TAG, "Bluetooth is not activated on the device.");
            Toast.makeText(activity, R.string.bt_bt_not_activated, Toast.LENGTH_SHORT).show();

            // Request to activate Bluetooth on the device. (The result is in MainActivity.class)
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            activity.startActivityForResult(intent, Constants.REQUEST_ENABLE_BT);
        }

        return true;
    }

    public static boolean checkOverhand(Context context) {
        Log.d(TAG, "checkOverhand() : checking");

        // Overhand 장치 연결 상태 확인
        int state = BluetoothAdapter.getDefaultAdapter().getProfileConnectionState(BluetoothProfile.GATT);
        if (state != BluetoothProfile.STATE_CONNECTED) {
            // 장치 미연결 상태
            return false;
        }

        BluetoothAdapter.getDefaultAdapter().getProfileProxy(context, new BluetoothProfile.ServiceListener() {
            @Override
            public void onServiceConnected(int i, BluetoothProfile bluetoothProfile) {
                for (BluetoothDevice connectedDevices : bluetoothProfile.getConnectedDevices()) {
                    Log.i(TAG, "checkOverhand() : onServiceConnected() | Device name : " + connectedDevices.getName() + " | Device Address : " + connectedDevices.getAddress() +
                            " | " + bluetoothProfile.getConnectionState(connectedDevices) + "(connected = " + BluetoothProfile.STATE_CONNECTED + ")");

                    // TODO: 연결된 장치가 Overhand 장치인지 확인 코드 필요
                }

                BluetoothAdapter.getDefaultAdapter().closeProfileProxy(i, bluetoothProfile);
            }

            @Override
            public void onServiceDisconnected(int i) {

            }
        }, BluetoothProfile.GATT);

        return true;
    }

    /*********************************************************************************************
     *	Handler, Listener, Timer, Sub classes
     *********************************************************************************************/

    // Various callback methods defined by the BLE API.
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                state = STATE_CONNECTED;
                Log.d(TAG, "onConnectionStateChange() : Connected to GATT server.");
                bleHandler.obtainMessage(MESSAGE_STATE_CHANGE, STATE_CONNECTED, 0).sendToTarget();

                gatt.discoverServices();

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                state = STATE_IDLE;
                Log.d(TAG, "onConnectionStateChange() : Disconnected from GATT server.");
                bleHandler.obtainMessage(MESSAGE_STATE_CHANGE, STATE_IDLE, 0).sendToTarget();
                bluetoothGatt = null;
                gattServices.clear();
                gattCharacteristics.clear();
                writableCharacteristics.clear();
                defaultChar = null;
                defaultDevice = null;
            }
        }

        @Override
        // New services discovered
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "onServicesDiscovered() : New GATT service discovered.");
                checkGattServices(gatt.getServices());
            } else {
                Log.d(TAG, "onServicesDiscovered() : onServicesDiscovered received: " + status);
            }
        }

        /**
         * Overhand 장치로부터 블루투스 통신을 통해 데이터 수신
         * @param gatt              GATT
         * @param characteristic    Characteristic
         * @param status            Status
         */
        @Override
        // Result of a characteristic read operation
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // We've received data from remote
                Log.d(TAG, "onCharacteristicRead() : "+characteristic.toString());

            	/*
            	 * onCharacteristicChanged callback receives same message
            	 */
/*                final byte[] data = characteristic.getValue();
                Log.d(TAG, "onCharacteristicRead() : The message(byte[]->String) is message(" +  + data[0] + ")(" + data[1] + ")(" + data[2] + ")(" + data[3] + ")");
                if (data.length > 0) {
            		bleHandler.obtainMessage(MESSAGE_READ, new String(data)).sendToTarget();
            	}

            	if(defaultChar == null && isWritableCharacteristic(characteristic)) {
            		defaultChar = characteristic;
            	}*/
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            // We've received data from remote
            Log.d(TAG, "onCharacteristicChanged() : "+characteristic.toString());

            final byte[] data = characteristic.getValue();

            Log.d(TAG, "onCharacteristicChanged() : The message(byte[]->String) is message(" +  + data[0] + ")(" + data[1] + ")(" + data[2] + ")(" + data[3] + ")");

            if (data.length > 0) {
                // Message Service로 메세지 전송
                int byteToInt = (data[0] & 0xff)<<24 | (data[1] & 0xff)<<16 | (data[2] & 0xff)<<8 | (data[3] & 0xff);
                bleHandler.obtainMessage(MESSAGE_READ, byteToInt, 0).sendToTarget();
            }

            if(defaultChar == null && isWritableCharacteristic(characteristic)) {
                defaultChar = characteristic;
            }
        }
    };
}
