package com.klasis.overhand;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.klasis.overhand.service.Message;
import com.klasis.overhand.utils.AppSettings;
import com.klasis.overhand.utils.Constants;

public class OptimizeSettings extends AppCompatActivity {

    // Debugging
    private final static String TAG = "OptimizeSettings";

    // System
    private Message msgService;
    private ImageView target;

    // UI
    private ImageView thumb;
    private ImageView index;
    private ImageView middle;
    private ImageView ring;
    private ImageView little;
    private TextView text;

    // Value
    private int thumb_value;
    private int index_value;
    private int middle_value;
    private int ring_value;
    private int little_value;

    // Timer
    private int targetFinger = 0;
    private long startTime = 0;
    private long endTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_optimizesettings);

        // 초기화
        thumb = (ImageView)findViewById(R.id.thumb);
        index = (ImageView)findViewById(R.id.index);
        middle = (ImageView)findViewById(R.id.middle);
        ring = (ImageView)findViewById(R.id.ring);
        little = (ImageView)findViewById(R.id.little);
        text = (TextView) findViewById(R.id.opt_text);
        text.setText(getString(R.string.opt_intro) + '\n' + getString(R.string.opt_progress));

        // Message 서비스 초기화
        msgService = AppSettings.getMsgService();
        if (msgService == null) {
            Log.d(TAG, "OptimizeSettings : Message Service is null");
            finish();
        }

        // Message 서비스에 OptimizeHandler 등록
        msgService.setOptimizeHandler(new OptimizeHandler());

        // 최적화 시작
        startOptimize();
    }

    @Override
    public void onBackPressed() {
        // Back 키 누르면 최적화 작업 중단 반환
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        // 자동 최적화 중단 처리
        msgService.sendMessage(Constants.OHP_TYPE_SEND, Constants.OHP_TARGET_INIT, 0);
        setResult(RESULT_CANCELED);
        super.onDestroy();
    }

    private void startOptimize() {
        Log.d(TAG, "startOptimize() : start");

        // 엄지 애니메이션 생성
        markAnim(thumb);

        // 엄지 압력 센서 값 요청
        msgService.sendMessage(Constants.OHP_TYPE_REQUEST, Constants.OHP_TARGET_FINGER5, 0, false);
        targetFinger = 1;
    }

    private void stopOptimize() {
        Log.d(TAG, "startOptimize() : start");

        text.setText(getString(R.string.opt_stop));

        // 손 이미지 숨기기
        ImageView hand = (ImageView) findViewById(R.id.hand);
        hand.setVisibility(View.INVISIBLE);

        // 완료 버튼 보이기
        Button btn = (Button) findViewById(R.id.opt_btn);
        btn.setVisibility(View.VISIBLE);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 최적화 작업 완료 반환 및 최적화 종료
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    private void markAnim(ImageView imageView) {
        // 애니메이션 타겟 지정
        target = imageView;

        // 애니메이션 생성
        target.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim));
    }

    private void clearAnim() {
        // 애니메이션 효과 중지
        thumb.clearAnimation();
        index.clearAnimation();
        middle.clearAnimation();
        ring.clearAnimation();
        little.clearAnimation();

        // animHandler 초기화
        target.clearAnimation();
    }

    class OptimizeHandler extends Handler {

        @Override
        public void handleMessage(android.os.Message msg) {
            Log.d(TAG, "# OptimizeHandler - handleMessage() : startTime(" + startTime +"), endTime(" + endTime + ")");
            switch (msg.what) {
                case Constants.MESSAGE_OPT_FINGER5:
                    if (targetFinger == 1) {
                        if (startTime == 0) {
                            // 타이머 시작
                            startTime = System.currentTimeMillis();
                        }
                        endTime = System.currentTimeMillis();

                        if (endTime - startTime < 3000) {
                            // 센서 값 임시 저장
                            thumb_value = msg.arg1;
                        } else {
                            // 센서 값 설정 요청
                            msgService.sendMessage(Constants.OHP_TYPE_SEND, Constants.OHP_TARGET_FINGER5, thumb_value);

                            // 엄지 압력 센서 값 저장
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER1, msg.arg1);

                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                            // 이전 애니메이션 중지
                            clearAnim();

                            // 검지 애니메이션 생성
                            markAnim(index);

                            // 검지 압력 센서 값 요청
                            msgService.sendMessage(Constants.OHP_TYPE_REQUEST, Constants.OHP_TARGET_FINGER4, 0, false);
                            targetFinger = 2;

                            // 타이머 초기화
                            startTime = 0;
                        }
                    }
                    break;

                case Constants.MESSAGE_OPT_FINGER4:
                    if (targetFinger == 2) {
                        if (startTime == 0) {
                            // 타이머 시작
                            startTime = System.currentTimeMillis();
                        }
                        endTime = System.currentTimeMillis();

                        if (endTime - startTime < 3000) {
                            // 센서 값 임시 저장
                            index_value = msg.arg1;
                        } else {
                            // 센서 값 설정 요청
                            msgService.sendMessage(Constants.OHP_TYPE_SEND, Constants.OHP_TARGET_FINGER4, index_value);

                            // 검지 압력 센서 값 저장
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER2, msg.arg1);

                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                            // 이전 애니메이션 중지
                            clearAnim();

                            // 중지 애니메이션 생성
                            markAnim(middle);

                            // 중지 압력 센서 값 요청
                            msgService.sendMessage(Constants.OHP_TYPE_REQUEST, Constants.OHP_TARGET_FINGER3, 0, false);
                            targetFinger = 3;

                            // 타이머 초기화
                            startTime = 0;
                        }
                    }
                    break;

                case Constants.MESSAGE_OPT_FINGER3:
                    if (targetFinger == 3) {
                        if (startTime == 0) {
                            // 타이머 시작
                            startTime = System.currentTimeMillis();
                        }
                        endTime = System.currentTimeMillis();

                        if (endTime - startTime < 3000) {
                            // 센서 값 임시 저장
                            middle_value = msg.arg1;
                        } else {
                            // 센서 값 설정 요청
                            msgService.sendMessage(Constants.OHP_TYPE_SEND, Constants.OHP_TARGET_FINGER3, middle_value);

                            // 중지 압력 센서 값 저장
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER3, msg.arg1);

                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                            // 이전 애니메이션 중지
                            clearAnim();

                            // 약지 애니메이션 생성
                            markAnim(ring);

                            // 약지 압력 센서 값 요청
                            msgService.sendMessage(Constants.OHP_TYPE_REQUEST, Constants.OHP_TARGET_FINGER2, 0, false);
                            targetFinger = 4;

                            // 타이머 초기화
                            startTime = 0;
                        }
                    }
                    break;

                case Constants.MESSAGE_OPT_FINGER2:
                    if (targetFinger == 4) {
                        if (startTime == 0) {
                            // 타이머 시작
                            startTime = System.currentTimeMillis();
                        }
                        endTime = System.currentTimeMillis();

                        if (endTime - startTime < 3000) {
                            // 센서 값 임시 저장
                            ring_value = msg.arg1;
                        } else {
                            // 센서 값 설정 요청
                            msgService.sendMessage(Constants.OHP_TYPE_SEND, Constants.OHP_TARGET_FINGER2, ring_value);

                            // 약지 압력 센서 값 저장
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER4, msg.arg1);

                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                            // 이전 애니메이션 중지
                            clearAnim();

                            // 소지 애니메이션 생성
                            markAnim(little);

                            // 소지 압력 센서 값 요청
                            msgService.sendMessage(Constants.OHP_TYPE_REQUEST, Constants.OHP_TARGET_FINGER1, 0, false);
                            targetFinger = 5;

                            // 타이머 초기화
                            startTime = 0;
                        }
                    }
                    break;

                case Constants.MESSAGE_OPT_FINGER1:
                    if (targetFinger == 5) {
                        if (startTime == 0) {
                            // 타이머 시작
                            startTime = System.currentTimeMillis();
                        }
                        endTime = System.currentTimeMillis();

                        if (endTime - startTime < 3000) {
                            // 센서 값 임시 저장
                            little_value = msg.arg1;
                        } else {
                            // 센서 값 설정 요청
                            msgService.sendMessage(Constants.OHP_TYPE_SEND, Constants.OHP_TARGET_FINGER1, little_value);

                            // 소지 압력 센서 값 저장
                            AppSettings.saveSettings(Constants.PREFERENCE_KEY_FINGER5, msg.arg1);

                            // 이전 애니메이션 중지
                            clearAnim();

                            targetFinger = 0;

                            // 최적화 종료
                            stopOptimize();
                        }
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    }
}
