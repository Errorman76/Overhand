package com.klasis.overhand;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.klasis.overhand.bluetooth.BleManager;
import com.klasis.overhand.service.Message;
import com.klasis.overhand.utils.AppSettings;
import com.klasis.overhand.utils.Constants;

public class MainActivity extends AppCompatActivity {

    // Debugging
    private static final String TAG = "MainActivity";

    // Context, System
    private Message msgService;
    private ActivityHandler activityHandler;

    // UI
    private Button btn_init;
    private SeekBar sb_press1;
    private SeekBar sb_press2;
    private SeekBar sb_press3;
    private SeekBar sb_press4;
    private SeekBar sb_press5;
    private SeekBar sb_gyro;
    private SeekBar sb_sleepmode;

    private TextView tv_press1;
    private TextView tv_press2;
    private TextView tv_press3;
    private TextView tv_press4;
    private TextView tv_press5;
    private TextView tv_gyro;
    private TextView tv_sleepmode;
    private TextView tv_state;

    // SeekBar
    private int minSeekBar = 1;
    private int maxSeekBar = 100;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ActionBar 초기화
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowCustomEnabled(true);        // ActionBar Custom 설정
            actionBar.setDisplayShowTitleEnabled(false);        // ActionBar Title 제거

            // 연걸 버튼 설정
            View main_view = getLayoutInflater().inflate(R.layout.layout_actionbar, null);
            main_view.findViewById(R.id.main_connection).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 오버핸드 연결
                    Intent intent = new Intent(MainActivity.this, DeviceListActivity.class);
                    startActivityForResult(intent, Constants.REQUEST_CONNECT_DEVICE);
                }
            });

            actionBar.setCustomView(main_view, new Toolbar.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // ActionBar 양 옆 공백 제거
            Toolbar parent =(Toolbar) main_view.getParent();
            parent.setContentInsetsAbsolute(0,0);
        }
        else {
            Log.d(TAG, "ActionBar object is null");
        }

        // System 초기화
        Context context = getApplicationContext();                  // Context 초기화
        activityHandler = new ActivityHandler();                    // ActivityHandler 생성
        AppSettings.initializeSettings(context);                    // AppSettings 초기화

        // Message 서비스 시작
        // startMsgService();

        // UI 초기화
        btn_init = (Button) findViewById(R.id.btn_init);
        sb_press1 = (SeekBar) findViewById(R.id.press_thumb_seekBar);
        sb_press2 = (SeekBar) findViewById(R.id.press_index_seekBar);
        sb_press3 = (SeekBar) findViewById(R.id.press_middle_seekBar);
        sb_press4 = (SeekBar) findViewById(R.id.press_ring_seekBar);
        sb_press5 = (SeekBar) findViewById(R.id.press_little_seekBar);
        tv_press1 = (TextView) findViewById(R.id.press_thumb_title);
        tv_press2 = (TextView) findViewById(R.id.press_index_title);
        tv_press3 = (TextView) findViewById(R.id.press_middle_title);
        tv_press4 = (TextView) findViewById(R.id.press_ring_title);
        tv_press5 = (TextView) findViewById(R.id.press_little_title);
        sb_gyro = (SeekBar) findViewById(R.id.gyro_seekBar);
        tv_gyro = (TextView) findViewById(R.id.gyro_title);
        sb_sleepmode = (SeekBar) findViewById(R.id.waiting_seekBar);
        tv_sleepmode = (TextView) findViewById(R.id.waiting_title);

        btn_init.setOnClickListener(onClickListener);

        sb_press1.setOnSeekBarChangeListener(onSeekBarChangeListener);
        sb_press2.setOnSeekBarChangeListener(onSeekBarChangeListener);
        sb_press3.setOnSeekBarChangeListener(onSeekBarChangeListener);
        sb_press4.setOnSeekBarChangeListener(onSeekBarChangeListener);
        sb_press5.setOnSeekBarChangeListener(onSeekBarChangeListener);
        sb_gyro.setOnSeekBarChangeListener(onSeekBarChangeListener);
        sb_sleepmode.setOnSeekBarChangeListener(onSeekBarChangeListener);

        sb_press1.setMax(maxSeekBar);
        sb_press2.setMax(maxSeekBar);
        sb_press3.setMax(maxSeekBar);
        sb_press4.setMax(maxSeekBar);
        sb_press5.setMax(maxSeekBar);
        sb_gyro.setMax(maxSeekBar);
        sb_sleepmode.setMax(maxSeekBar);

        // 최적화 버튼 설정
        btn_init.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    // 최적화 버튼을 누름
                    case MotionEvent.ACTION_DOWN:
                        btn_init.setBackground(getResources().getDrawable(R.drawable.btn_shapes_pressed, null));
                        break;
                    // 최적화 버튼을 누르지 않음
                    case MotionEvent.ACTION_UP:
                        btn_init.setBackground(getResources().getDrawable(R.drawable.btn_shapes, null));
                        break;
                }

                return false;
            }
        });

        // 상태 바 설정
        tv_state = (TextView) findViewById(R.id.state);
        tv_state.setText(getResources().getText(R.string.bt_state_init));


        tv_state.setText("연결됨(" + new Float(3.14f)  + ")");
        Log.d(TAG, "MessageHandler - receiveMessage() : Type(0)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Type(1)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Type(2)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(0)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(1)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(2)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(3)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(4)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(5)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(6)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(7)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Target(8)");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Type is -1");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Type is 3");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Target of OHP_TYPE_SEND is -1");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Target of OHP_TYPE_SEND is 9");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Type is 29154");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Type is -2147483647");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Type is 2147483648");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Target of OHP_TYPE_SEND is 1904125");
        Log.d(TAG, "MessageHandler - receiveMessage() : Message Target of OHP_TYPE_SEND is 135985");
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        // finalizeOH();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // finalizeOH();
        super.onBackPressed();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    /**
     * Button 클릭 이벤트 처리
     */
    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_init:
                    Intent intent = new Intent(getApplicationContext(), OptimizeSettings.class);            // OptimizeSettings 화면 이동
                    startActivityForResult(intent, Constants.REQUEST_OPTIMIZE);
                    break;
            }
        }
    };

    /**
     * SeekBar 이벤트 처리
     */
    private SeekBar.OnSeekBarChangeListener onSeekBarChangeListener = new SeekBar.OnSeekBarChangeListener() {

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            int id = seekBar.getId();

            // SeekBar 움직이는 중일 때 호출
            if (id == sb_press1.getId()) {
                if (progress < minSeekBar)  tv_press1.setText("엄지 압력센서 감도 (" + (seekBar.getProgress() + 1) + "%)");
                else    tv_press1.setText("엄지 압력센서 감도 (" + seekBar.getProgress() + "%)");
            }
            else if(id == sb_press2.getId()) {
                if (progress < minSeekBar)  tv_press2.setText("검지 압력센서 감도 (" + (seekBar.getProgress() + 1) + "%)");
                else    tv_press2.setText("검지 압력센서 감도 (" + seekBar.getProgress() + "%)");
            }
            else if(id == sb_press3.getId()) {
                if (progress < minSeekBar)  tv_press3.setText("중지 압력센서 감도 (" + (seekBar.getProgress() + 1) + "%)");
                else    tv_press3.setText("중지 압력센서 감도 (" + seekBar.getProgress() + "%)");
            }
            else if(id == sb_press4.getId()) {
                if (progress < minSeekBar)  tv_press4.setText("약지 압력센서 감도 (" + (seekBar.getProgress() + 1) + "%)");
                else    tv_press4.setText("약지 압력센서 감도 (" + seekBar.getProgress() + "%)");
            }
            else if(id == sb_press5.getId()) {
                if (progress < minSeekBar)  tv_press5.setText("소지 압력센서 감도 (" + (seekBar.getProgress() + 1) + "%)");
                else    tv_press5.setText("소지 압력센서 감도 (" + seekBar.getProgress() + "%)");
            }
            else if(id == sb_gyro.getId()) {
                if (progress < minSeekBar)  tv_gyro.setText("자이로센서 감도 (" + (seekBar.getProgress() + 1) + "%)");
                else    tv_gyro.setText("자이로센서 감도 (" + seekBar.getProgress() + "%)");
            }
            else {
                if(progress == 100)   tv_sleepmode.setText("절전모드 (Off)");
                else if (progress < minSeekBar) tv_sleepmode.setText("절전모드 (" + ((progress) + 1) + "분)");
                else    tv_sleepmode.setText("절전모드 (" + progress + "분)");

            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
            // SeekBar 움직일 때 호출
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            int id = seekBar.getId();
            int cvt_mode, send_target;
            String pref_key;

            // SeekBar 멈출 때 호출
            if (id == sb_press1.getId()) {
                cvt_mode = Constants.CVT_PRESSURE_SENSOR;
                pref_key = Constants.PREFERENCE_KEY_FINGER1;
                send_target = Constants.OHP_TARGET_FINGER1;
            }
            else if(id == sb_press2.getId()) {
                cvt_mode = Constants.CVT_PRESSURE_SENSOR;
                pref_key = Constants.PREFERENCE_KEY_FINGER2;
                send_target = Constants.OHP_TARGET_FINGER2;
            }
            else if(id == sb_press3.getId()) {
                cvt_mode = Constants.CVT_PRESSURE_SENSOR;
                pref_key = Constants.PREFERENCE_KEY_FINGER3;
                send_target = Constants.OHP_TARGET_FINGER3;
            }
            else if(id == sb_press4.getId()) {
                cvt_mode = Constants.CVT_PRESSURE_SENSOR;
                pref_key = Constants.PREFERENCE_KEY_FINGER4;
                send_target = Constants.OHP_TARGET_FINGER4;
            }
            else if(id == sb_press5.getId()) {
                cvt_mode = Constants.CVT_PRESSURE_SENSOR;
                pref_key = Constants.PREFERENCE_KEY_FINGER5;
                send_target = Constants.OHP_TARGET_FINGER5;
            }
            else if(id == sb_gyro.getId()) {
                cvt_mode = Constants.CVT_GYRO_SENSOR;
                pref_key = Constants.PREFERENCE_KEY_GYRO;
                send_target = Constants.OHP_TARGET_GYRO;
            }
            else if(id == sb_sleepmode.getId()) {
                cvt_mode = Constants.CVT_SLEEP_MODE;
                pref_key = Constants.PREFERENCE_KEY_SLEEP_MODE;
                send_target = Constants.OHP_TARGET_SLEEP;
            }
            else {
                // 예외 처리
                Log.e(TAG, "onStopTrackingTouch() : CANNOT find SeekBar Id (" + id + ")");
                return;
            }

            // 변경된 값을 변환
            int value;
            if (seekBar.getProgress() < minSeekBar)
                value = AppSettings.convertSettings(cvt_mode, seekBar.getProgress() + 1, true);
            else
                value = AppSettings.convertSettings(cvt_mode, seekBar.getProgress(), true);

            // 변경된 값을 저장
            AppSettings.saveSettings(pref_key, value);

            // 변경된 값을 Overhand 장치로 전송
            msgService.sendMessage(Constants.OHP_TYPE_SEND, send_target, value);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "onActivityResult() : " + requestCode);

        switch (requestCode) {
            case Constants.REQUEST_CONNECT_DEVICE:
                if (resultCode == Activity.RESULT_OK) {
                    Log.i(TAG, "onActivityResult() - REQUEST_CONNECT_DEVICE : MAC Address is " + data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS));

                    // 연결할 Overhand의 MAC address 가져오기
                    String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);

                    // 장치 연결 요청
                    if(address != null && msgService != null)
                        msgService.connectDevice(address);
                }
                break;

            case Constants.REQUEST_ENABLE_BT:
                if (resultCode == Activity.RESULT_OK) {
                    // 블루투스 활성화
                    Log.d(TAG, "onActivityResult() - REQUEST_ENABLE_BT : Bluetooth is activated");
                }
                else {
                    // 블루투스 활성화 거절
                    Log.e(TAG, "onActivityResult() - REQUEST_ENABLE_BT : Bluetooth is not activated by the user who rejected the request");
                    Toast.makeText(this, R.string.req_bt_not_activated, Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;

            case Constants.REQUEST_OPTIMIZE:
                Log.d(TAG, "onActivityResult() - REQUEST_OPTIMIZE : return");
                if (resultCode == Activity.RESULT_OK) {
                    // 설정 값 업데이트
                    loadSettings();
                }
                connectedSettings();
                break;
        }
    }

    private void initialSettings() {
        Log.d(TAG, "initialSettings() : start");

        // 오버핸드 장치 초기화 요청
        msgService.sendMessage(Constants.OHP_TYPE_SEND, Constants.OHP_TARGET_INIT, 0);

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // 오버핸드 장치로부터 설정 값 초기화를 위해 설정 값 요청
        msgService.sendMessage(Constants.OHP_TYPE_REQUEST, Constants.OHP_TARGET_PRESSURE, 0, true);
    }

    private void loadSettings() {
        Log.d(TAG, "loadSettings() : start");

        // 이전 설정 값 불러오기
        int pref_press1 = AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER1);
        int pref_press2 = AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER2);
        int pref_press3 = AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER3);
        int pref_press4 = AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER4);
        int pref_press5 = AppSettings.loadSettings(Constants.PREFERENCE_KEY_FINGER5);
        int pref_gyro = AppSettings.loadSettings(Constants.PREFERENCE_KEY_GYRO);
        int pref_sleep = AppSettings.loadSettings(Constants.PREFERENCE_KEY_SLEEP_MODE);

        if ((pref_press1 == -1) || (pref_press2 == -1) || (pref_press3 == -1) || (pref_press4 == -1) ||
                (pref_press5 == -1) || (pref_gyro == -1) || (pref_sleep == -1)) {
            Log.d(TAG, "onCreate() : need to initialize settings");

            Toast.makeText(this, R.string.pref_need_initialize, Toast.LENGTH_SHORT).show();
        }
        else {
            // 압력 센서 설정
            sb_press1.setProgress(AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, pref_press1, false));
            sb_press2.setProgress(AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, pref_press2, false));
            sb_press3.setProgress(AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, pref_press3, false));
            sb_press4.setProgress(AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, pref_press4, false));
            sb_press5.setProgress(AppSettings.convertSettings(Constants.CVT_PRESSURE_SENSOR, pref_press5, false));
            sb_gyro.setProgress(AppSettings.convertSettings(Constants.CVT_GYRO_SENSOR, pref_gyro, false));
            tv_press1.setText("엄지 압력센서 감도 (" + sb_press1.getProgress() + "%)");
            tv_press2.setText("검지 압력센서 감도 (" + sb_press2.getProgress() + "%)");
            tv_press3.setText("중지 압력센서 감도 (" + sb_press3.getProgress() + "%)");
            tv_press4.setText("약지 압력센서 감도 (" + sb_press4.getProgress() + "%)");
            tv_press5.setText("소지 압력센서 감도 (" + sb_press5.getProgress() + "%)");

            // 자이로 센서 설정
            tv_gyro.setText("자이로센서 감도 (" + sb_gyro.getProgress() + "%)");

            // 절전 모드 설정
            sb_sleepmode.setProgress(pref_sleep);
            if (sb_sleepmode.getProgress() == 100)   tv_sleepmode.setText("절전모드 (Off)");
            else    tv_sleepmode.setText("절전모드 (" + sb_sleepmode.getProgress() + "분)");
        }
    }

    private void connectedSettings() {
        btn_init.setEnabled(true);
        btn_init.setTextColor(getResources().getColor(R.color.colorText));
        sb_press1.setEnabled(true);
        sb_press2.setEnabled(true);
        sb_press3.setEnabled(true);
        sb_press4.setEnabled(true);
        sb_press5.setEnabled(true);
        sb_gyro.setEnabled(true);
        sb_sleepmode.setEnabled(true);
    }

    private void disconnectedSettings() {
        btn_init.setEnabled(false);
        btn_init.setTextColor(getResources().getColor(R.color.colorDisable));
        sb_press1.setEnabled(false);
        sb_press2.setEnabled(false);
        sb_press3.setEnabled(false);
        sb_press4.setEnabled(false);
        sb_press5.setEnabled(false);
        sb_gyro.setEnabled(false);
        sb_sleepmode.setEnabled(false);
    }

    private void initializeOH() {
        Log.d(TAG, "initializeOH() : start");

        msgService.setupService(activityHandler);

        // 블루투스 연결 해제
        msgService.disconnectDevice();

        // Message 서비스 저장
        AppSettings.setMsgService(msgService);

        // 블루투스 상태 확인
        BleManager.checkBluetooth(this);
    }

    private void finalizeOH() {
        Log.d(TAG, "finalizeOH() : start");

        if(!AppSettings.getBgService()) {
            StopMsgService();
        }
    }

    /**
     * Message 서비스 시작
     */
    private void startMsgService() {
        Log.d(TAG, "startMsgService() : start Message service");

        bindService(new Intent(this, Message.class), msgServiceConn, Context.BIND_AUTO_CREATE);
    }

    /**
     * Message 서비스 종료
     */
    private void StopMsgService() {
        Log.d(TAG, "StopMsgService() : stop Message service");

        // msgService.finalizeService();
        stopService(new Intent(this, Message.class));
    }

    /**
     * Message 서비스 연결
     */
    private ServiceConnection msgServiceConn = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Log.d(TAG, "msgServiceConn : Message Service connected");

            msgService = ((Message.MessageBinder) iBinder).getService();

            // 연결될 때까지 Activity가 msgService와 함께 동작하지 않을 경우 초기화 (onCreate() 실행 동안 초기화 금지)
            initializeOH();
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.d(TAG, "msgServiceConn : Message Service disconnected");

            msgService = null;
        }
    };

    class ActivityHandler extends Handler {

        @Override
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                // Receives BT state messages from service
                // and updates BT state UI
                case Constants.MESSAGE_BT_STATE_INITIALIZED:
                    disconnectedSettings();
                    tv_state.setText(getResources().getString(R.string.bt_state_init));
                    break;
                case Constants.MESSAGE_BT_STATE_LISTENING:
                    disconnectedSettings();
                    tv_state.setText(getResources().getString(R.string.bt_state_wait));
                    break;
                case Constants.MESSAGE_BT_STATE_CONNECTING:
                    disconnectedSettings();
                    tv_state.setText(getResources().getString(R.string.bt_state_connect));
                    break;
                case Constants.MESSAGE_BT_STATE_CONNECTED:
                    connectedSettings();
                    if(msgService != null) {
                        String deviceName = msgService.getDeviceName();
                        if(deviceName != null) {
                            tv_state.setText(getResources().getString(R.string.bt_state_connected) + " (" + deviceName + ")");
                        } else {
                            tv_state.setText(getResources().getString(R.string.bt_state_connected) + " (이름없음)");
                        }
                        try {
                            Thread.sleep(1000);
                            initialSettings();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case Constants.MESSAGE_BT_STATE_ERROR:
                    disconnectedSettings();
                    tv_state.setText(getResources().getString(R.string.bt_state_error));
                    break;

                // BT Command status
                case Constants.MESSAGE_CMD_ERROR_NOT_CONNECTED:
                    disconnectedSettings();
                    tv_state.setText(getResources().getString(R.string.bt_cmd_sending_error));
                    break;

                case Constants.INITIAL_SETTINGS:
                    Log.d(TAG, "ActivityHandler - handleMessage() : Initialize Settings");
                    loadSettings();
                    break;

                default:
                    break;
            }
            super.handleMessage(msg);
        }
    }
}