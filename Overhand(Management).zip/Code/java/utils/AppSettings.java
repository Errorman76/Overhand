package com.klasis.overhand.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.klasis.overhand.service.Message;

/**
 * 앱 설정 관리 클래스
 * Created by Klasis on 2017-08-28.
 */

public class AppSettings {

    // Debugging
    private final static String TAG = "AppSettings";

    // Constants
    private final static int PRESSURE_MINIMUM = 10;
    private final static int PRESSURE_MAXIMUM = 710;
    private final static int PRESSURE_RATIO = (PRESSURE_MAXIMUM - PRESSURE_MINIMUM) / 100;
    private final static int GYRO_MINIMUM = 300;
    private final static int GYRO_MAXIMUM = 500;
    private final static int GYRO_RATIO = (GYRO_MAXIMUM - GYRO_MINIMUM) / 100;

    // System
    private static Context context;
    private static Message msgService;
    private static boolean isInitialized = false;
    private static boolean useBackgroundService;


    public static void initializeSettings(Context c) {
        // 초기화 중복 확인
        if(isInitialized)
            return;

        // Context 및 백그라운드 서비스 상태 값 초기화
        context = c;
        useBackgroundService = loadBgService();

        isInitialized = true;
    }

    public static void saveSettings(String type, int intValue) {
        if (context == null) {
            Log.e(TAG, "saveSettings() : Context is null");
            return;
        }

        SharedPreferences pref = context.getSharedPreferences(Constants.PREFERENCE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = pref.edit();

        edit.putInt(type, intValue);
        edit.apply();

        Log.d(TAG, "saveSettings() : Type(" + type + "), Value(" + intValue + "), Result(" + pref.getInt(type, -1) + ")");
    }

    public static int loadSettings(String type) {
        if (context == null) {
            Log.e(TAG, "loadSettings() : Context is null");
            return -1;
        }

        SharedPreferences pref = context.getSharedPreferences(Constants.PREFERENCE_NAME, Context.MODE_PRIVATE);

        Log.d(TAG, "loadSettings() : Type(" + type + "), getValue(" + pref.getInt(type, -1) + ")");
        return pref.getInt(type, -1);
    }

    /**
     * 앱 설정 값과 하드웨어 설정 값 변환
     * @param type          설정 타입
     * @param intValue      설정 값
     * @param reverse       true : 앱 설정 값 -> 하드웨어 설정 값 / false : 앱 설정 값 <- 하드웨어 설정 값
     * @return              변환 값
     */
    public static int convertSettings(int type, int intValue, boolean reverse) {
        switch (type) {
            // 압력 센서
            case Constants.CVT_PRESSURE_SENSOR:
                if (reverse)
                    return (intValue * PRESSURE_RATIO) + PRESSURE_MINIMUM;
                else
                    return (intValue - PRESSURE_MINIMUM) / PRESSURE_RATIO;

            // 자이로 센서
            case Constants.CVT_GYRO_SENSOR:
                if (reverse)
                    return (intValue * GYRO_RATIO) + GYRO_MINIMUM;
                else
                    return (intValue - GYRO_MINIMUM) / GYRO_RATIO;

            // 절전 모드
            case Constants.CVT_SLEEP_MODE:
                return intValue;

            default:
                return -1;
        }
    }

    public static void setMsgService(Message messageService) {
        msgService = messageService;
    }

    public static Message getMsgService() {
        return msgService;
    }

    /**
     * 설정으로부터 백그라운드 서비스 상태 값 반환
     * @return      백그라운드 서비스 상태 값
     */
    private static boolean loadBgService() {
        SharedPreferences prefs = context.getSharedPreferences(Constants.PREFERENCE_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(Constants.PREFERENCE_KEY_BG_SERVICE, false);
    }

    /**
     * AppSettings로부터 백그라운드 서비스 상태 값 반환
     * @return      백그라운드 서비스 상태 값
     */
    public static boolean getBgService() {
        return useBackgroundService;
    }
}
