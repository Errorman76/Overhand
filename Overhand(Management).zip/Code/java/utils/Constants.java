package com.klasis.overhand.utils;

/**
 * 상수들의 집합
 * Created by klasis on 2017-08-10.
 */

public class Constants {

    // Intent request codes
    public final static int REQUEST_CONNECT_DEVICE = 1;
    public final static int REQUEST_ENABLE_BT = 2;
    public final static int REQUEST_OPTIMIZE = 3;

    // Preference
    public final static String PREFERENCE_NAME = "settings";
    public final static String PREFERENCE_KEY_BG_SERVICE = "BackgroundService";
    public final static String PREFERENCE_CONN_INFO_ADDRESS = "device_address";
    public final static String PREFERENCE_CONN_INFO_NAME = "device_name";

    public final static String PREFERENCE_KEY_FINGER1 = "Pref_Finger1";
    public final static String PREFERENCE_KEY_FINGER2 = "Pref_Finger2";
    public final static String PREFERENCE_KEY_FINGER3 = "Pref_Finger3";
    public final static String PREFERENCE_KEY_FINGER4 = "Pref_Finger4";
    public final static String PREFERENCE_KEY_FINGER5 = "Pref_Finger5";
    public final static String PREFERENCE_KEY_GYRO = "Pref_Gyro";
    public final static String PREFERENCE_KEY_SLEEP_MODE = "Pref_Sleep_mode";

    public final static int CVT_PRESSURE_SENSOR = 1;
    public final static int CVT_GYRO_SENSOR = 2;
    public final static int CVT_SLEEP_MODE = 3;

    // Overhand Protocol - Message Type
    public final static int OHP_TYPE_REQUEST = 0;
    public final static int OHP_TYPE_RESPONSE = 1;
    public final static int OHP_TYPE_SEND = 2;

    // Overhand Protocol - Message Target
    public final static int OHP_TARGET_PRESSURE = 0;
    public final static int OHP_TARGET_FINGER1 = 1;
    public final static int OHP_TARGET_FINGER2 = 2;
    public final static int OHP_TARGET_FINGER3 = 3;
    public final static int OHP_TARGET_FINGER4 = 4;
    public final static int OHP_TARGET_FINGER5 = 5;
    public final static int OHP_TARGET_GYRO = 7;
    public final static int OHP_TARGET_SLEEP = 6;
    public final static int OHP_TARGET_INIT = 15;

    // Message types sent from Service to Activity
    public final static int MESSAGE_CMD_ERROR_NOT_CONNECTED = -50;

    // Message handler
    public final static int MESSAGE_BT_STATE_INITIALIZED = 1;
    public final static int MESSAGE_BT_STATE_LISTENING = 2;
    public final static int MESSAGE_BT_STATE_CONNECTING = 3;
    public final static int MESSAGE_BT_STATE_CONNECTED = 4;
    public final static int MESSAGE_BT_STATE_DISCONNECTED = 5;
    public final static int MESSAGE_BT_STATE_ERROR = 10;
    public final static int MESSAGE_KEY_SEND_KEYVALUE = 15;
    public final static int INITIAL_SETTINGS = 17;

    // Optimize handler
    public final static int MESSAGE_OPT_FINGER1 = 1;
    public final static int MESSAGE_OPT_FINGER2 = 2;
    public final static int MESSAGE_OPT_FINGER3 = 3;
    public final static int MESSAGE_OPT_FINGER4 = 4;
    public final static int MESSAGE_OPT_FINGER5 = 5;

    // Key
    public final static int KEYCODE_NUM = 1;
    public final static int KEYCODE_CHAR = 2;
    public final static int KEYCODE_ENTER = 3;
    public final static int KEYCODE_SPACE = 4;
    public final static int KEYCODE_DELETE = 5;
}
