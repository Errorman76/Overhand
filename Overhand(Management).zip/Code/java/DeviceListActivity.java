package com.klasis.overhand;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import com.klasis.overhand.bluetooth.BleManager;

public class DeviceListActivity extends Activity {

    // Debugging
    private final static String TAG = "DeviceListActivity";

    // Constants
    public final static long SCAN_PERIOD = 8*1000;                      // 스캔 타이머 값
    
    // Return Intent extra
    public static String EXTRA_DEVICE_ADDRESS = "device_address";

    // Member fields
    private BluetoothAdapter btAdapter;
    private BleManager bleManager;
    private ScanHandler scanHandler;
    private ArrayAdapter<String> connectedDeviceArrayAdapter;
    private ArrayAdapter<String> pairedDevicesArrayAdapter;
    private ArrayAdapter<String> newDevicesArrayAdapter;
    private ArrayList<BluetoothDevice> devicesList;

    // UI
    private Button scanButton;
    private ProgressBar searchPb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Setup the window
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_device_list);

        // 결과 반환 값 설정(기본)
        setResult(Activity.RESULT_CANCELED);

        // BleManager 초기화 및 LeScanCallback 정보 전달
        bleManager = BleManager.getInstance(null);
        bleManager.setLeScanCallback(mScanCallback);

        // 오버핸드 장치와의 블루투스 연결 상태
        if (bleManager.getState() == bleManager.STATE_CONNECTED) {
            // 연결된 상태
            // 연결된 장치 타이틀 및 리스트 표시
            findViewById(R.id.title_connected_device).setVisibility(View.VISIBLE);
            findViewById(R.id.list_connected_device).setVisibility(View.VISIBLE);

            // 나머지 장치 타이틀 및 리스트 표시 해제
            findViewById(R.id.title_paired_devices).setVisibility(View.GONE);
            findViewById(R.id.list_paired_devices).setVisibility(View.GONE);
            findViewById(R.id.title_new_devices).setVisibility(View.GONE);
            findViewById(R.id.list_new_devices).setVisibility(View.GONE);

            // 연결된 장치 리스트 초기화
            connectedDeviceArrayAdapter = new ArrayAdapter<>(this, R.layout.adapter_device_list);
            ListView connectedListView = (ListView) findViewById(R.id.list_connected_device);
            connectedListView.setAdapter(connectedDeviceArrayAdapter);
            connectedDeviceArrayAdapter.add("OVERHAND\n연결됨");
            connectedDeviceArrayAdapter.notifyDataSetChanged();

            scanButton = (Button) findViewById(R.id.button_scan);
            scanButton.setText(getResources().getString(R.string.button_disconnect));
            scanButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 장치 연결 해제
                    bleManager.disconnect();
                    finish();
                }
            });
        }
        else {
            // 스캔 타이머 Handler 초기화
            scanHandler = new ScanHandler();

            // 스캔 버튼 초기화 및 클릭 이벤트 처리
            scanButton = (Button) findViewById(R.id.button_scan);
            searchPb = (ProgressBar) findViewById(R.id.search_progress);
            scanButton.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    // 등록되지 않은 장치 타이틀 표시
                    findViewById(R.id.title_new_devices).setVisibility(View.VISIBLE);

                    // 등록되지 않은 장치 리스트 표시
                    findViewById(R.id.list_new_devices).setVisibility(View.VISIBLE);

                    // 등록되지 않은 장치 리스트 초기화
                    newDevicesArrayAdapter.clear();

                    // 스캔 버튼 숨김
                    v.setVisibility(View.GONE);
                    searchPb.setVisibility(View.VISIBLE);

                    // 등록되지 않은 장치 검색
                    startDiscovery();
                }
            });

            // ArrayAdapter 선언
            pairedDevicesArrayAdapter = new ArrayAdapter<>(this, R.layout.adapter_device_list);
            newDevicesArrayAdapter = new ArrayAdapter<>(this, R.layout.adapter_device_list);

            // 페어링된 장치의 ListView 초기화 및 Adapter 설정
            ListView pairedListView = (ListView) findViewById(R.id.list_paired_devices);
            pairedListView.setAdapter(pairedDevicesArrayAdapter);
            pairedListView.setOnItemClickListener(mDeviceClickListener);

            // 새 장치의 ListView 초기화 및 Adapter 설정
            ListView newDevicesListView = (ListView) findViewById(R.id.list_new_devices);
            newDevicesListView.setAdapter(newDevicesArrayAdapter);
            newDevicesListView.setOnItemClickListener(mDeviceClickListener);

            // 검색된 장치 리스트 초기화
            devicesList = new ArrayList<>();

            // BluetoothAdapter 초기화
            btAdapter = BluetoothAdapter.getDefaultAdapter();

            // 페어링된 장치 검색
            scanPairedDevices();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // 장치 검색 취소
        if (btAdapter != null) {
            stopDiscovery();
        }
    }

    /**
     * 페어링된 장치 검색
     */
    private void scanPairedDevices() {
        Log.d(TAG, "scanPairedDevices() : start (scan)");

        // 페어링된 장치 리스트 불러오기
        Set<BluetoothDevice> pairedDevices = btAdapter.getBondedDevices();

        if (pairedDevices.size() > 0) {
            // 페어링된 장치가 있을 경우
            // 페어링된 장치 타이틀 표시
            findViewById(R.id.title_paired_devices).setVisibility(View.VISIBLE);
            for (BluetoothDevice device : pairedDevices) {
                if (device.getName().compareTo("OVERHAND") == 0)
                    pairedDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
            }
        } else {
            Log.d(TAG, "aaaaaaaaaaaaaaa : " + pairedDevices.size());
            // 페어링된 장치가 없을 경우
            String noDevices = getResources().getText(R.string.none_paired).toString();
            pairedDevicesArrayAdapter.add(noDevices);
        }
        pairedDevicesArrayAdapter.notifyDataSetChanged();
    }

    /**
     * BluetoothAdapter로 등록되지 않은 장치 검색 시작
     */
    private void startDiscovery() {
        Log.d(TAG, "startDiscovery() : start (scan)");

        // 미등록된 장치 타이틀 표시
        findViewById(R.id.title_new_devices).setVisibility(View.VISIBLE);

        // 검색된 장치 리스트 초기화
        devicesList.clear();

        // 장치 검색 중복 검사
        if (bleManager.getState() == BleManager.STATE_SCANNING) {
            bleManager.scanLeDevice(false);
        }

        // BLE 스캐너의 장치 검색 시작
        bleManager.scanLeDevice(true);
        
        // 지정된 시간동안 스캔
        scanHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopDiscovery();
            }
        }, SCAN_PERIOD);
    }

    /**
     * BluetoothAdapter로 등록되지 않은 장치 검색 중지
     */
    private void stopDiscovery() {
        Log.d(TAG, "stopDiscovery() : start (stop)");

        // BLE 스캐너의 장치 검색 중지
        bleManager.scanLeDevice(false);

        if (newDevicesArrayAdapter.getCount() == 0) {
            // 등록되지 않은 장치 리스트가 없을 경우
            newDevicesArrayAdapter.add(getResources().getText(R.string.none_found).toString());
        }

        // 스캔 버튼 표시
        searchPb.setVisibility(View.GONE);
        scanButton.setVisibility(View.VISIBLE);
    }

    /**
     * 검색된 장치 리스트의 중복 검사
     * @param device    중복 검사할 블루투스 장치
     * @return          중복 여부의 결과 반환
     */
    private boolean checkDuplicated(BluetoothDevice device) {
        for(BluetoothDevice dvc : devicesList) {
            if(device.getAddress().equalsIgnoreCase(dvc.getAddress())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 검색된 블루투스 장치에 대한 이벤트 처리
     */
    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            Log.i(TAG, "ScanCallback : Scan device(" + result.getDevice().getName() + "), RSSI(" + result.getRssi() + ")");

            // 검색 결과로부터 블루투스 장치 추출
            BluetoothDevice device = result.getDevice();

            // 검색된 블루투스 장치에 대한 페어링 여부 검사
            if(device.getBondState() != BluetoothDevice.BOND_BONDED) {
                // 검색된 블루투스 장치에 대한 중복 검사 (검색 결과 리스트와 비교)
//              if (!checkDuplicated(device)) {
                if (device != null && device.getName() != null && device.getName().compareTo("OVERHAND") == 0) {
                    // 검색된 블루투스 장치(이름, MAC 주소)를 검색된 장치 리스트에 추가
                    newDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                    // 검색된 장치 리스트 새로고침
                    newDevicesArrayAdapter.notifyDataSetChanged();
                    devicesList.add(device);
                }
            }
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for(ScanResult mScanResult : results)
                Log.i(TAG, "onBatchScanResults() : " + mScanResult.toString());
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
        }
    };

    /**
     * 페어링된 혹은 새 장치의 Listview에 대한 클릭 이벤트 처리
     */
    private OnItemClickListener mDeviceClickListener = new OnItemClickListener() {
        public void onItemClick(AdapterView<?> av, View v, int arg2, long arg3) {
            // 장치 검색 중지
            stopDiscovery();

            // Get the device MAC address, which is the last 17 chars in the View
            String info = ((TextView) v).getText().toString();
            if (info.length() > 16) {
                String address = info.substring(info.length() - 17);
                Log.d(TAG, "mDeviceClickListener : User selected the device(" + address + ")");

                // Intent 결과와 MAC address 정보 생성
                Intent intent = new Intent();
                intent.putExtra(EXTRA_DEVICE_ADDRESS, address);

                // 결과 반환값 설정 및 Activity 종료
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
        }
    };

    private class ScanHandler extends Handler {
        
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
        }
    }
}
