package com.klasis.overhand;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.provider.Settings;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.Toast;

public class PreSettingsActivity extends Activity {

    // Debugging
    private final static String TAG = "PreSettingsActivity";

    // UI
    private Button btn_setting1;
    private Button btn_setting2;
    private Button btn_confirm;

    // Back Button
    private int backTime = 2;   // per a second
    private long backTimer = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_pre_settings);

        // UI 초기화
        btn_setting1 = (Button) findViewById(R.id.presettings_btn_setting1);
        btn_setting2 = (Button) findViewById(R.id.presettings_btn_setting2);
        btn_confirm = (Button) findViewById(R.id.presettings_btn_confirm);

        btn_setting1.setOnClickListener(onClickListener);
        btn_setting2.setOnClickListener(onClickListener);
        btn_confirm.setOnClickListener(onClickListener);

        btn_setting1.setOnTouchListener(onTouchListener);
        btn_setting2.setOnTouchListener(onTouchListener);
        btn_confirm.setOnTouchListener(onTouchListener);
    }

    Button.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.presettings_btn_setting1:
                    Log.d(TAG, "PreSettingsActivity : register Overhand keyboard");

                    // Overhand 키보드 등록 바로가기
                    Intent intent = new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS);
                    startActivity(intent);
                    break;

                case R.id.presettings_btn_setting2:
                    Log.d(TAG, "PreSettingsActivity : set Overhand keyboard");

                    // Overhand 키보드 설정 바로가기
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null)
                        imm.showInputMethodPicker();
                    break;

                case R.id.presettings_btn_confirm:
                    Log.d(TAG, "PreSettingsActivity : confirm");

                    // 오버핸드 키보드 연결 확인
                    if (Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD).equals(getString(R.string.overhand_keyboard))) {
                        // 창 종료
                        finish();
                    } else {
                        Toast.makeText(PreSettingsActivity.this, R.string.presettings_not_set, Toast.LENGTH_SHORT).show();
                    }
                    break;
                default:
                    break;
            }
        }
    };

    Button.OnTouchListener onTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (v.getId()) {
                case R.id.presettings_btn_setting1:
                    switch (event.getAction()) {
                        // 버튼을 누름
                        case MotionEvent.ACTION_DOWN:
                            btn_setting1.setBackground(getResources().getDrawable(R.drawable.btn_shapes_pressed, null));
                            break;
                        // 버튼을 누르지 않음
                        case MotionEvent.ACTION_UP:
                            btn_setting1.setBackground(getResources().getDrawable(R.drawable.btn_shapes, null));
                            break;
                    }
                    break;
                case R.id.presettings_btn_setting2:
                    switch (event.getAction()) {
                        // 버튼을 누름
                        case MotionEvent.ACTION_DOWN:
                            btn_setting2.setBackground(getResources().getDrawable(R.drawable.btn_shapes_pressed, null));
                            break;
                        // 버튼을 누르지 않음
                        case MotionEvent.ACTION_UP:
                            btn_setting2.setBackground(getResources().getDrawable(R.drawable.btn_shapes, null));
                            break;
                    }
                    break;
                case R.id.presettings_btn_confirm:
                    switch (event.getAction()) {
                        // 버튼을 누름
                        case MotionEvent.ACTION_DOWN:
                            btn_confirm.setBackground(getResources().getDrawable(R.drawable.btn_shapes_pressed, null));
                            break;
                        // 버튼을 누르지 않음
                        case MotionEvent.ACTION_UP:
                            btn_confirm.setBackground(getResources().getDrawable(R.drawable.btn_shapes, null));
                            break;
                    }
                    break;
                default:
                    break;
            }
            return false;
        }
    };

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // 외부 영역 터치 방지
        // return super.onTouchEvent(event);
        return false;
    }

    @Override
    public void onBackPressed() {
        // Back 버튼 방지
        // super.onBackPressed();

        // 1번 뒤로가기
        if (backTimer == 0) {
            // Back button timer
            backTimer = System.currentTimeMillis();

            Toast.makeText(this, R.string.sys_back_button, Toast.LENGTH_SHORT).show();

        }
        // 2번 뒤로가기
        else {
            // 2초 이내 뒤로가기
            if (System.currentTimeMillis() - backTimer <= backTime * 1000) {
                // 앱 종료
                finishAffinity();
            }
            // 2초 이후 뒤로가기
            else {
                // Back button timer
                backTimer = System.currentTimeMillis();

                Toast.makeText(this, R.string.sys_back_button, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class PreSettingsHandler extends Handler {

    }
}
