package com.klasis.overhand;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.klasis.overhand.bluetooth.BleManager;
import com.klasis.overhand.utils.Constants;

public class Intro extends AppCompatActivity {

    // Debugging
    private final static String TAG = "Intro";

    // Constant
    private final static int PERMISSION_ACCESS_COARSE_LOCATION = 1;

    private Handler introHandler;
    private Runnable run = new Runnable() {
        @Override
        public void run() {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);                // Main 화면 이동
            startActivity(intent);
            finish();                                                                               // Intro 화면 종료
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        // Coarse Location 접근 권한 확인
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        if (permissionCheck == PackageManager.PERMISSION_DENIED) {
            Log.i(TAG, "There is no access permission of coarse location");

            // 접근 권한이 없을 경우
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_ACCESS_COARSE_LOCATION);
        }

        // 블루투스 상태 확인
        if (!BleManager.checkBluetooth(this))
            finish();

        // Overhand 키보드 설정 확인
        if (!checkKeyboard()) {
            // Overhand 키보드가 설정되지 않은 경우
            Log.d(TAG, "onCreate() : Overhand is NOT current keyboard");

            // Overhand 연결 가이드 호출
            Intent intent = new Intent(this, PreSettingsActivity.class);
            startActivityForResult(intent, Constants.REQUEST_CONNECT_DEVICE);
        }

        // Handler 초기화
        introHandler = new Handler();
    }

    // 외부에서 화면 복귀
    @Override
    protected void onResume() {
        super.onResume();
        introHandler.postDelayed(run, 1000);                                                             // 1000 ms 후 run() 진행
    }

    // 화면에서 벗어남
    @Override
    protected void onPause() {
        super.onPause();
        introHandler.removeCallbacks(run);                                                               // introHandler 중단
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_ACCESS_COARSE_LOCATION:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.i(TAG, "onRequestPermissionsResult() - PERMISSION_ACCESS_COARSE_LOCATION : The request of access coarse location is granted");

                    // 접근 권한 허가
                }
                else {
                    Log.e(TAG, "onRequestPermissionsResult() - PERMISSION_ACCESS_COARSE_LOCATION : The request of access coarse location is denied");

                    // 접근 권한 거부
                    Toast.makeText(this, R.string.pms_request_denied, Toast.LENGTH_SHORT).show();
                    finish();
                }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "onActivityResult() : " + requestCode + ", " + resultCode);

        switch (requestCode) {
            case Constants.REQUEST_ENABLE_BT:
                if (resultCode == Activity.RESULT_OK) {
                    // 블루투스 활성화
                    Log.d(TAG, "onActivityResult() - REQUEST_ENABLE_BT : Bluetooth is activated");
                }
                else {
                    // 블루투스 활성화 거절
                    Log.e(TAG, "onActivityResult() - REQUEST_ENABLE_BT : Bluetooth is not activated by the user who rejected the request");
                    Toast.makeText(this, R.string.req_bt_not_activated, Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
        }
    }

    /**
     * Overhand 키보드 설정 확인
     */
    public boolean checkKeyboard() {
        Log.d(TAG, "checkKeyboard() : check");

        return Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD).equals(getString(R.string.overhand_keyboard));
    }
}
